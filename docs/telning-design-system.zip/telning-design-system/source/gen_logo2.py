import os, cairosvg
from logo2 import *
from palette import P
D = '/home/claude/telning/assets2/Logo'; os.makedirs(D, exist_ok=True)
W = lambda n, s: open(os.path.join(D, n), 'w').write(s)
W('colophon.svg', colophon_svg(P['red'], P['cream'], mono=False))
W('colophon-mono.svg', colophon_svg())
W('lockup.svg', lockup_svg(badge=P['red'], book=P['cream'], ink=P['ink'], mono=False))
W('lockup-mono.svg', lockup_svg())
W('lockup-stacked.svg', lockup_svg(stacked=True, badge=P['red'], book=P['cream'], ink=P['ink'], mono=False))
W('favicon.svg', favicon_svg())
W('profile.svg', profile_svg())
cairosvg.svg2png(bytestring=favicon_svg().encode(), write_to=os.path.join(D, 'favicon-32.png'), output_width=32, output_height=32)
cairosvg.svg2png(bytestring=icon_svg(0.66, rounded=False).encode(), write_to=os.path.join(D, 'apple-touch-icon.png'), output_width=180, output_height=180)
cairosvg.svg2png(bytestring=og_svg().encode(), write_to=os.path.join(D, 'og-image.png'), output_width=1200, output_height=630)
cairosvg.svg2png(bytestring=profile_svg().encode(), write_to='/home/claude/telning/out2/profile.png', output_width=300, output_height=300)
for n in sorted(os.listdir(D)): print(n, os.path.getsize(os.path.join(D, n)))
