import re, json, os, glob
from playwright.sync_api import sync_playwright
from harness2 import frame_html
import render2
from content2 import S
P = '/home/claude/telning/ds2/project'; OUT = '/home/claude/telning/out2'
res = {}
NEVER = ['proven', 'clinically tested', 'science-backed', 'boosts vocabulary', 'builds language skills', 'calming', 'reduces anxiety', 'mindful colouring',
         'stops tantrums', 'social story', 'therapy', 'for autism', 'for adhd', 'therapist-approved', 'first book of its kind', 'best', 'number one', 'award',
         'treats', 'cures', 'medical', 'diagnosis', 'by a doctor', 'twentythird', 'day-23', 'wellowork']
hits = []
for f in glob.glob(P + '/components/*/preview.html') + [P + '/components/bundle.js'] + glob.glob(P + '/assets/Site data/*.json'):
    txt = re.sub(r'<svg.*?</svg>', '', open(f).read(), flags=re.S).lower()
    txt = txt.replace('© 2026 wellowork ab, telning publishing house', '').replace('© {year} wellowork ab, telning publishing house', '').replace('"company": "wellowork ab"', '')
    for w in NEVER:
        for m in re.finditer(r'(?<![a-z])' + re.escape(w) + r'(?![a-z])', txt):
            hits.append((os.path.relpath(f, P), w, txt[max(0, m.start()-30):m.end()+30]))
res['never_words'] = hits
JS = r'''() => {
 function parse(c){ const m=c.match(/rgba?\(([^)]+)\)/); if(!m) return null; const p=m[1].split(/[ ,\/]+/).filter(Boolean).map(parseFloat); return {r:p[0],g:p[1],b:p[2],a:p.length>3?p[3]:1}; }
 function lum(c){ const f=v=>{v/=255; return v<=0.03928? v/12.92 : Math.pow((v+0.055)/1.055,2.4)}; return 0.2126*f(c.r)+0.7152*f(c.g)+0.0722*f(c.b); }
 function bgOf(el){ while(el){ const cs=getComputedStyle(el); const c=parse(cs.backgroundColor); if(c && c.a>0.5) return c; el=el.parentElement; } return {r:246,g:241,b:232,a:1}; }
 const out=[]; const w=document.createTreeWalker(document.querySelector('.tn-page'), NodeFilter.SHOW_TEXT); let n; const seen=new Set();
 while((n=w.nextNode())){ const t=n.textContent.trim(); if(!t) continue; const el=n.parentElement; if(seen.has(el)) continue; seen.add(el);
   if(el.closest('[aria-hidden="true"]:not(.tn-cover__t):not(.tn-cover__k):not(.tn-age__n),.tn-hp,.tn-sr,script,style')) continue;
   const cs=getComputedStyle(el); if(cs.display==='none'||cs.visibility==='hidden') continue; const r=el.getBoundingClientRect(); if(r.width===0) continue;
   const fg=parse(cs.color), bg=bgOf(el); const L1=lum(fg),L2=lum(bg); const ratio=(Math.max(L1,L2)+.05)/(Math.min(L1,L2)+.05);
   const size=parseFloat(cs.fontSize), wt=parseInt(cs.fontWeight); const large=size>=24||(size>=18.66&&wt>=700);
   out.push({t:t.slice(0,40),ratio:Math.round(ratio*100)/100,need:large?3:4.5});
 } return out; }'''
def lengthen(d):
    out = {}
    for k, v in d.items():
        if '{' in v: out[k] = v; continue
        extra = max(2, int(len(v) * 0.3)); out[k] = v + (' Längerwort' * (extra // 11 + 1))[:extra]
    return out
with sync_playwright() as pw:
    b = pw.chromium.launch(); pg = b.new_page(); reqs = []
    pg.on('request', lambda r: reqs.append(r.url))
    long_body = None
    old = dict(render2.S); render2.S.update(lengthen(old)); long_body = render2.landing(); render2.S.clear(); render2.S.update(old)
    res['overflow'] = {}
    for variant in ('normal', 'long'):
        if variant == 'long':
            path = frame_html('LandingPage', lambda s: s[:s.index('<body>') + 7] + long_body + s[s.index('<script>Telning.init'):]); os.replace(path, OUT + '/frame-long.html'); path = OUT + '/frame-long.html'
        else:
            path = frame_html('LandingPage')
        for w in (360, 390, 800, 1280):
            pg.set_viewport_size({'width': w, 'height': 820}); pg.goto('file://' + path); pg.wait_for_timeout(200)
            sw = pg.evaluate('document.documentElement.scrollWidth')
            clipped = pg.evaluate('''() => [...document.querySelectorAll('.tn-page h1,.tn-page h2,.tn-page h3,.tn-page p,.tn-page a,.tn-page button,.tn-page span.tn-pill,.tn-page label')].filter(e => e.scrollWidth > e.clientWidth + 1 && getComputedStyle(e).overflowX==='visible' && e.clientWidth>0 && !e.closest('.tn-spine') && !e.closest('[aria-hidden=true]')).map(e => e.className+':'+e.textContent.trim().slice(0,30)).slice(0,6)''')
            res['overflow'][f'{variant}-{w}'] = {'scrollWidth': sw, 'ok': sw <= w, 'text_overflow': clipped}
            if variant == 'long' and w in (360,):
                pg.evaluate("document.querySelectorAll('.tn-reveal').forEach(e=>e.classList.add('is-in'))"); pg.wait_for_timeout(800); pg.screenshot(path=f'{OUT}/long-{w}.png', full_page=True)
    path = frame_html('LandingPage')
    res['contrast_fail'] = []
    for w in (390, 1280):
        pg.set_viewport_size({'width': w, 'height': 820}); pg.goto('file://' + path); pg.wait_for_timeout(200)
        pg.evaluate("document.querySelectorAll('.tn-reveal').forEach(e=>e.classList.add('is-in'))"); pg.wait_for_timeout(900)
        res['contrast_fail'] += [(w, i) for i in pg.evaluate(JS) if i['ratio'] < i['need']]
    res['h1'] = pg.evaluate("document.querySelectorAll('.tn-page h1').length")
    res['bad_values'] = pg.evaluate(r"() => ['undefined','null','None','[name]','NaN'].filter(w => document.querySelector('.tn-page').innerText.includes(w))")
    res['buttons'] = pg.evaluate("() => [...document.querySelectorAll('.tn-page .tn-btn')].map(e => Math.round(e.getBoundingClientRect().top + scrollY))")
    # keyboard
    pg.set_viewport_size({'width': 1280, 'height': 820}); pg.goto('file://' + path); pg.wait_for_timeout(100)
    pg.evaluate("() => document.querySelectorAll('*').forEach((e,i)=>e.dataset.idx=i)")
    focusables = pg.evaluate("() => [...document.querySelectorAll('.tn-page a[href], .tn-page button, .tn-page input:not([type=hidden]):not([tabindex=\"-1\"])')].filter(e => e.offsetParent && !e.closest('.tn-hp')).length")
    seen = []; bad = []
    for i in range(90):
        pg.keyboard.press('Tab')
        info = pg.evaluate("() => { const e=document.activeElement; const cs=getComputedStyle(e); return {idx:e.dataset.idx, ow:cs.outlineWidth, os:cs.outlineStyle, inPage: !!e.closest('.tn-page'), txt:(e.innerText||'').slice(0,20)} }")
        if info['inPage']:
            seen.append(info['idx'])
            if not (info['ow'] == '3px' and info['os'] == 'solid'): bad.append(info)
    res['keyboard'] = {'focusable': focusables, 'reached': len(set(seen)), 'bad_ring': bad[:4]}
    res['small_targets'] = pg.evaluate("() => [...document.querySelectorAll('.tn-page a[href], .tn-page button, .tn-page input')].filter(e => e.offsetParent && !e.closest('.tn-hp') && !e.closest('p')).map(e => {const r=e.getBoundingClientRect(); return [e.textContent.trim().slice(0,25), Math.round(r.width), Math.round(r.height)]}).filter(x => x[2] < 44 || x[1] < 44)")
    # reduced motion: nothing hidden, nothing moving
    ctx = b.new_context(reduced_motion='reduce'); p2 = ctx.new_page(); p2.set_viewport_size({'width': 1280, 'height': 820}); p2.goto('file://' + path); p2.wait_for_timeout(300)
    res['reduced_motion'] = p2.evaluate("() => ({hidden:[...document.querySelectorAll('.tn-reveal')].filter(e => getComputedStyle(e).opacity !== '1').length, anims: document.getAnimations().length})")
    ctx.close()
    # menu + email
    pg.set_viewport_size({'width': 390, 'height': 820}); pg.goto('file://' + path); pg.wait_for_timeout(100)
    pg.click('.tn-menu-btn'); res['menu'] = pg.evaluate("[getComputedStyle(document.getElementById('tn-nav')).display, document.querySelector('.tn-menu-btn').getAttribute('aria-expanded')]")
    pg.set_viewport_size({'width': 1280, 'height': 820}); pg.goto('file://' + path); pg.wait_for_timeout(100)
    chip = 'n/a (no book links on the home page now)'
    pg.click('#news .tn-btn'); e1 = pg.evaluate("document.querySelector('#news .tn-error-text').textContent")
    pg.fill('#news-email', 'sam@example.com'); pg.click('#news .tn-btn'); pg.wait_for_timeout(700)
    res['email'] = {'chip': chip, 'err': e1, 'done': pg.evaluate("document.querySelector('#news').classList.contains('is-done')")}
    res['external'] = sorted(set(u for u in reqs if not u.startswith(('file://', 'data:'))))
    b.close()
print(json.dumps(res, indent=1, ensure_ascii=False))
