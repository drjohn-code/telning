"""Builds the Telning design system (Direction 2 · paper theatre) under ds2/project/."""
import json, os, html, re
from palette import P
from objects import svg as osvg, OBJ, SERIES_EMBLEM, ANIMALS
from logo2 import lockup_svg, colophon_svg
from content2 import SITE_DATA as D, S, SERIES, SERIES_NOTES, AGES, SKILLS, SKILL_MAIN, SERIES_SCENES, AGE_ANIMALS

ROOT = '/home/claude/telning/ds2/project'
OUT = '/home/claude/telning/out2'
HERE = os.path.dirname(os.path.abspath(__file__))
E = html.escape

def write(path, text):
    full = os.path.join(ROOT, path); os.makedirs(os.path.dirname(full), exist_ok=True); open(full, 'w').write(text)

def t(k, **kw):
    v = S[k]
    for a, b in kw.items(): v = v.replace('{' + a + '}', str(b))
    return E(v)

# ======================================================================== tokens
USAGE = {
    'paper': 'Page background. Ground for ink text (17:1) and every section.',
    'paper-deep': 'Paper in shadow: object shading, quiet fills. Not a text ground for small text.',
    'cream': 'Cards, book covers, the email block; text on forest, ink, red and sea-deep.',
    'white': 'Form fields and art slots.',
    'ink': 'All text on paper, cream, blush, sky, gold, moss and rose. The primary button.',
    'ink-soft': 'Dev labels and object details. Text on paper only when 14 px or more.',
    'red': 'The colophon, the signature accent, link underlines, TADA letters. Cream text on it (4.7:1).',
    'red-deep': 'Kickers, error lines, shaded red in objects. Text on paper and cream (6.6:1).',
    'red-light': 'Lit side of red objects. Never under text.',
    'forest': 'The TADA band and the footer; button hover. Cream text on it (9.8:1).',
    'forest-light': 'Hills and leaves. Shading only.',
    'moss': 'Far hills and leaves. Ink text on it (6.8:1) on the Flowers & Nature spine.',
    'gold': 'Sun, balloons, gift ribbons; Celebrations spine with ink text.',
    'gold-deep': 'Shaded gold in objects.', 'gold-light': 'Lit gold, the 5–7 age card and Things That Go spine with ink text.',
    'blush': 'The 0–3 age card and Food & Cooking spine, with ink text.', 'rose': 'Superheroes spine with ink text; frosting.',
    'sky': 'The 3–5 age card and Toys spine, with ink text.', 'sky-light': 'The hero stage sky.',
    'sea': 'Planets, balls, seesaw: objects only (cream on sea is under 4.5:1).', 'sea-deep': 'Space spine with cream text (7:1); focus ring.',
}
def tokens():
    color = [{'name': k, 'value': v.lower(), 'usage': USAGE.get(k, '')} for k, v in list(P.items())[:5]]
    color.insert(3, {'name': 'white', 'value': '#ffffff', 'usage': USAGE['white']})
    color += [{'name': k, 'value': v.lower(), 'usage': USAGE.get(k, '')} for k, v in list(P.items())[5:]]
    return {
        'name': 'Telning', 'version': 2,
        'color': {'themes': [{'id': 'light', 'name': 'Light'}], 'tokens': color},
        'type': {
            'fonts': [{'family': 'Fraunces', 'file': 'fonts/Fraunces-600.woff2', 'weight': '600', 'style': 'normal'},
                      {'family': 'Fraunces', 'file': 'fonts/Fraunces-400.woff2', 'weight': '400', 'style': 'normal'},
                      {'family': 'Instrument Sans', 'file': 'fonts/InstrumentSans-400.woff2', 'weight': '400', 'style': 'normal'},
                      {'family': 'Instrument Sans', 'file': 'fonts/InstrumentSans-600.woff2', 'weight': '600', 'style': 'normal'}],
            'families': {'display': '"Fraunces", Georgia, serif', 'text': '"Instrument Sans", system-ui, sans-serif'},
            'groups': [
                {'name': 'Display', 'family': 'display', 'styles': [
                    {'name': 'display-xl', 'fontSize': '96px', 'lineHeight': '0.98', 'fontWeight': 600, 'letterSpacing': '-0.015em', 'sample': 'Little stories, growing minds.', 'usage': 'The page title (H1) on desktop. 64 px tablet, 40 px phone.'},
                    {'name': 'display-l', 'fontSize': '60px', 'lineHeight': '1.05', 'fontWeight': 600, 'sample': 'Find a book by age', 'usage': 'Section headings (H2) on desktop. 44 px tablet, 28 px phone.'},
                    {'name': 'display-age', 'fontSize': '150px', 'lineHeight': '0.9', 'fontWeight': 600, 'sample': '0–3', 'usage': 'Age numbers on age cards.'},
                    {'name': 'display-m', 'fontSize': '26px', 'lineHeight': '1.15', 'fontWeight': 600, 'sample': 'Colouring stories', 'usage': 'Card headings (H3). 24 px tablet, 19 px phone.'},
                    {'name': 'display-quote', 'fontSize': '42px', 'lineHeight': '1.2', 'fontWeight': 400, 'sample': 'Hi, I’m Pim!', 'usage': 'Pim’s speech bubbles and other quiet statements (17–19 px there).'},
                ]},
                {'name': 'Text', 'family': 'text', 'styles': [
                    {'name': 'lead', 'fontSize': '20px', 'lineHeight': '1.55', 'fontWeight': 400, 'sample': 'Silent books and colouring stories.', 'usage': 'The first paragraph under a heading. 17 px on phones.'},
                    {'name': 'body', 'fontSize': '18px', 'lineHeight': '1.6', 'fontWeight': 400, 'sample': 'Your child colours the story, then finishes it.', 'usage': 'All body text. 16 px on phones.'},
                    {'name': 'body-strong', 'fontSize': '18px', 'lineHeight': '1.6', 'fontWeight': 600, 'sample': 'See the books', 'usage': 'Links, buttons, labels.'},
                    {'name': 'kicker', 'fontSize': '13px', 'lineHeight': '1.4', 'fontWeight': 600, 'letterSpacing': '0.16em', 'sample': 'SILENT BOOKS · AGES 0–7', 'usage': 'Small capitals over a heading, in red-deep.'},
                    {'name': 'small', 'fontSize': '14px', 'lineHeight': '1.5', 'fontWeight': 400, 'sample': 'First name and age only.', 'usage': 'Notes and consent lines.'},
                ]},
            ]},
        'spacing': {'tokens': [{'name': f's{i}', 'value': v, 'usage': u} for i, (v, u) in enumerate([
            ('4px', 'Hairline gaps.'), ('8px', 'Inside pill rows; spine gaps.'), ('12px', 'Card meta gaps.'), ('16px', 'Phone gutter; card gaps on phones.'),
            ('24px', 'Card padding; tablet gutter.'), ('32px', 'Desktop gutter; big card padding.'), ('48px', 'Space under section heads.'),
            ('64px', 'Section padding on phones; band padding.'), ('96px', 'Section padding on desktop.')], start=1)]},
        'radius': {'tokens': [
            {'name': 'radius-s', 'value': '8px', 'usage': 'Small controls.'}, {'name': 'radius-m', 'value': '16px', 'usage': 'Art slots, TADA cards.'},
            {'name': 'radius-l', 'value': '28px', 'usage': 'Age cards, the stage, bands, the email block.'}, {'name': 'radius-pill', 'value': '999px', 'usage': 'Buttons, pills, fields.'}]},
        'shadow': {'note': 'Depth for the paper theatre: soft, warm, ink-tinted. Objects use the same feel as a drop shadow.', 'tokens': [
            {'name': 'shadow-1', 'value': '0 1px 2px rgba(22,20,15,0.10), 0 4px 10px rgba(22,20,15,0.08)', 'usage': 'Chips, small cards, spine badges.'},
            {'name': 'shadow-2', 'value': '0 2px 4px rgba(22,20,15,0.08), 0 14px 30px rgba(22,20,15,0.12)', 'usage': 'Cards, covers, the stage, buttons.'},
            {'name': 'shadow-3', 'value': '0 4px 8px rgba(22,20,15,0.10), 0 28px 50px rgba(22,20,15,0.18)', 'usage': 'Lifted: hover, the email block, books in a list.'}]},
        'layout': {'tokens': [{'name': 'content-max', 'value': '1180px', 'usage': 'Widest content box.'}, {'name': 'text-max', 'value': '640px', 'usage': 'Widest text column.'}]},
        'duration': {'note': 'Motion is small and slow. All of it stops under prefers-reduced-motion.', 'tokens': [{'name': 'move', 'value': '220ms', 'usage': 'Hover and state changes.'}]},
        'easing': {'tokens': [{'name': 'ease', 'value': 'cubic-bezier(0.2,0.7,0.3,1)', 'usage': 'Every transition: quick start, soft landing.'}]},
    }

def tokens_css(tk):
    out = [':root{']
    out += [f'--{x["name"]}:{x["value"]};' for x in tk['color']['tokens']]
    for fam in ('spacing', 'radius', 'shadow', 'layout', 'duration', 'easing'):
        out += [f'--{x["name"]}:{x["value"]};' for x in tk[fam]['tokens']]
    out += [f'--font-{k}:{v};' for k, v in tk['type']['families'].items()]
    out.append('}')
    for fo in tk['type']['fonts']:
        out.append(f'@font-face{{font-family:"{fo["family"]}";src:url("/home/claude/telning/ds2/project/{fo["file"]}") format("woff2");font-weight:{fo["weight"]};font-display:swap}}')
    return '\n'.join(out)

# ======================================================================== pieces
def obj(name, w, cls='', style='', label=None):
    st = f'--w:{w}px;{style}' if isinstance(w, int) else f'--w:{w};{style}'
    s = osvg(name, cls=f'tn-obj {cls}'.strip(), label=label)
    return s.replace('<svg ', f'<svg style="{st}" ', 1)

def layer(d, style, inner, cls=''):
    return f'<div class="tn-layer {cls}" style="--d:{d};{style}" aria-hidden="true">{inner}</div>'

HILLS = {
    'far': 'M0 300V52C40 30 80 20 130 28s90 26 140 20 90-34 130-30v230z',
    'mid': 'M0 300V46C50 26 110 18 170 30s110 22 160 6 60-20 70-18v236z',
    'near': 'M0 300V40C70 22 140 18 210 28s130 14 190-2v234z',
}
def hill(kind, fill):
    return f'<svg class="tn-hill" viewBox="0 0 400 300" preserveAspectRatio="none" aria-hidden="true"><path d="{HILLS[kind]}" fill="var(--{fill})"/></svg>'

def cover(l1, l2, colour, file, kicker='Series', image=''):
    col = colophon_svg('var(--red)', 'var(--cream)', mono=False, inline=True, cls='tn-cover__colophon')
    if image:
        return f'<div class="tn-cover"><img src="{E(image)}" alt="Cover of {E((l1 + " " + l2).strip())}" width="600" height="800" loading="lazy"></div>'
    l1h = f'<span class="tn-cover__l1">{E(l1)}</span>' if l1 else ''
    return (f'<div class="tn-cover" style="--book:var(--{colour})"><span class="tn-cover__band"></span>{col}'
            f'<span class="tn-cover__k" aria-hidden="true">{E(kicker)}</span>'
            f'<p class="tn-cover__t" aria-hidden="true">{l1h}<span class="tn-cover__l2">{E(l2)}</span></p>'
            f'<span class="tn-cover__art" data-file="{E(file)}" aria-hidden="true"></span></div>')

# series shown as covers (no book titles yet)
SERIES_COVERS = [('Home &', 'Hearts', 'red', 'home-hearts'), ('Star', 'Hoppers', 'sea-deep', 'star-hoppers'), ('On the', 'Move', 'gold', 'on-the-move'),
                 ('Paws &', 'Claws', 'forest', 'paws-claws'), ('Big', 'Days', 'rose', 'big-days'), ('The Toy', 'Box', 'sky', 'toy-box')]
def series_cover(i):
    l1, l2, col, key = SERIES_COVERS[i]
    return cover(l1, l2, col, f'series-{key}.png')

def slot(file, ratio=''):
    r = f' tn-slot--{ratio}' if ratio else ''
    return f'<div class="tn-slot{r}" data-file="{E(file)}" aria-hidden="true"></div>'

def pim_note(key, file, cls='', size=''):
    """Pim, the Telning character, speaking. The picture is the illustrator's (an art slot until it exists)."""
    return (f'<figure class="tn-pim {size} {cls}"><div class="tn-pim__art">{slot(file, "round")}</div>'
            f'<figcaption class="tn-pim__bubble"><span class="tn-sr">{t("pim.sign")}: </span>{t(key)}</figcaption></figure>')

def stage():
    books = ''.join(f'<div class="tn-tilt" data-tilt="10">{series_cover(i)}</div>' for i in range(3))
    return f'''<div class="tn-hero__art"><div class="tn-stage tn-scene">
  <div class="tn-stage__box" style="container-type:inline-size">
    {layer(4, 'top:7%;right:7%;width:22%', obj('sun', '100%', 'tn-spin'))}
    {layer(8, 'top:10%;left:0;width:100%', '<div class="tn-drift" style="--drift:58s;width:24%">' + obj('cloud', '100%') + '</div>')}
    {layer(12, 'top:26%;left:0;width:100%', '<div class="tn-drift" style="--drift:84s;animation-delay:-40s;width:17%">' + obj('cloud', '100%') + '</div>')}
    {layer(10, 'top:40%;bottom:-15%;left:0;width:100%', hill('far', 'moss'))}
    {layer(14, 'bottom:51%;left:8%;width:12%', obj('tree', '100%'), 'tn-hide-sm')}
    {layer(18, 'top:57%;bottom:-15%;left:0;width:100%', hill('mid', 'forest-light'))}
    {layer(20, 'bottom:38%;right:9%;width:9%', obj('signpost', '100%'))}
    {layer(22, 'bottom:33%;left:10%;width:12%', '<div class="tn-hop-idle">' + obj('bunny', '100%') + '</div>')}
    {layer(16, 'top:12%;right:30%;width:11%', '<div class="tn-float">' + obj('bee', '100%') + '</div>', 'tn-hide-sm')}
    <div class="tn-plane-wrap tn-layer" style="--d:30;inset:0" aria-hidden="true"><div class="tn-plane">{obj('plane', 70)}</div></div>
    {layer(30, 'top:76%;bottom:-15%;left:0;width:100%', hill('near', 'forest'))}
    <div class="tn-layer" style="--d:34;left:22%;bottom:9%;" ><div class="tn-books3">{books}</div></div>
    {layer(40, 'bottom:3%;left:0;width:100%', '<div class="tn-drive">' + obj('car', 92, 'tn-wheels') + '</div>')}
  </div>
  {layer(46, 'top:-7%;left:44%;width:17%', '<div class="tn-float slow">' + obj('balloon', '100%', 'tn-sway') + '</div>')}
  {layer(54, 'bottom:-7%;left:-6%;width:23%', '<div class="tn-float late">' + obj('blocks', '100%') + '</div>')}
  {layer(60, 'bottom:-6%;right:-4%;width:20%', '<div class="tn-peek">' + obj('fox', '100%') + '</div>')}
</div>
{pim_note("pim.hello", "pim-hello.png", "tn-hero__pim")}
</div>'''

def age_strip():
    out = ''
    for key, label, name, col in AGES:
        out += (f'<li><a class="tn-agechip tn-reveal" href="/books?age={key}" style="--c:var(--{col})">'
                f'<span class="tn-agechip__n" aria-hidden="true">{label}</span>'
                f'<span class="tn-agechip__l">{E(name)}<span class="tn-sr">, ages {label}</span></span>'
                f'<span class="tn-agechip__obj" aria-hidden="true">{obj(AGE_ANIMALS[key], "100%")}</span></a></li>')
    return (f'<div class="tn-ages"><h2 class="tn-ages__h" id="ages-h">{t("ages.h2")}</h2><ul class="tn-agestrip">{out}</ul></div>')

GROUND = '<svg class="tn-world__ground" viewBox="0 0 400 60" preserveAspectRatio="none" aria-hidden="true"><path d="M0 60V26C60 8 130 2 200 14s140 18 200 4v42z" fill="var(--cream)"/></svg>'
FAR = '<svg class="tn-world__far" viewBox="0 0 400 80" preserveAspectRatio="none" aria-hidden="true"><path d="M0 80V40C70 14 150 10 230 28s120 12 170-8v60z" fill="var(--cream)" opacity=".28"/></svg>'
def world(key, name, theme):
    col, items = SERIES_SCENES[key]
    objs = ''.join(f'<div class="tn-world__o {cls}" style="left:{l}%;bottom:{b}%;width:{w}%">{obj(n, "100%")}</div>' for n, l, b, w, cls in items)
    return (f'<a class="tn-world tn-tilt" data-tilt="8" href="/series/{key}">'
            f'<span class="tn-world__scene" style="--c:var(--{col})" aria-hidden="true">{FAR}{objs}{GROUND}</span>'
            f'<span class="tn-world__body"><span class="tn-world__name">{E(name)}</span><span class="tn-world__theme">{E(theme)}</span></span></a>')

def worlds():
    lis = ''.join(f'<li class="tn-reveal">{world(k, n, th)}</li>' for k, n, th, *_ in SERIES)
    return f'<ul class="tn-worlds">{lis}</ul>'

def book_card(b):
    """b: dict(l1, l2, colour, file, title, age, status, key, amazon)."""
    out = b.get('status') == 'out'
    action = (f'<a class="tn-link" href="{E(b["amazon"])}">{t("book.amazon")}</a>' if out and b.get('amazon')
              else f'<a class="tn-link" href="#news" data-tn-notify="{E(b["key"])}">{t("book.notify")}</a>')
    return (f'<article class="tn-bookcard"><div class="tn-tilt" data-tilt="12">{cover(b["l1"], b["l2"], b["colour"], b["file"], b.get("kicker", "Series"))}</div>'
            f'<h3 class="tn-h3" style="font-size:20px">{E(b["title"])}</h3>'
            f'<div class="tn-bookcard__meta"><span class="tn-pill">{t("book.age", min=b["age"][0], max=b["age"][1])}</span>'
            f'<span class="tn-pill tn-pill--dark">{t("book.status.out") if out else t("book.status.coming")}</span></div>{action}</article>')

def skills():
    k, name, text, o = SKILL_MAIN
    side = ''
    for key, n, tx, ob in SKILLS:
        anim = {'heart': 'tn-float', 'steps': 'tn-float late', 'seesaw': 'tn-float slow'}[ob]
        side += (f'<li class="tn-skillrow tn-reveal"><div class="tn-skillrow__obj" aria-hidden="true">{obj(ob, 84, anim)}</div>'
                 f'<div><h3 class="tn-h3">{E(n)}</h3><p class="tn-p">{E(tx)}</p></div></li>')
    main = (f'<div class="tn-skillmain tn-tilt tn-reveal" data-tilt="5"><div class="tn-skillmain__obj tn-pop-far" aria-hidden="true"><div class="tn-float slow">{obj(o, "100%")}'
            f'<div class="tn-skillmain__owl">{obj("owl", "100%")}</div></div></div>'
            f'<h3 class="tn-skillmain__h">{E(name)}</h3><p class="tn-lead">{E(text)}</p></div>')
    return (f'<div class="tn-skillmap">{main}<div class="tn-skillside">'
            f'<ul class="tn-skillrows">{side}</ul>{pim_note("pim.skills", "pim-question.png", "tn-reveal")}</div></div>')

import math as _m
def seal(cls='tn-seal'):
    """The science seal: a red rosette, a cream ring with turning words, the colophon book in the middle."""
    pts = []
    n = 22
    for i in range(n):
        a = 2 * _m.pi * i / n
        pts.append(f'<circle cx="{80 + 68 * _m.cos(a):.1f}" cy="{80 + 68 * _m.sin(a):.1f}" r="11"/>')
    ring = 'M80 80m-47 0a47 47 0 1 1 94 0a47 47 0 1 1-94 0'
    book = ('M50 50C60 40 74 37 86 40L85 56C73 53 60 56 54.5 61V101.5A4.5 4.5 0 0 1 45.5 101.5V61'
            'C40 56 27 53 15 56L14 40C26 37 40 40 50 50Z')
    return (f'<svg class="{cls}" viewBox="0 0 160 160" aria-hidden="true" focusable="false">'
            f'<g fill="var(--red)"><circle cx="80" cy="80" r="68"/>{"".join(pts)}</g>'
            f'<circle cx="80" cy="80" r="60" fill="var(--cream)"/>'
            f'<g class="o-ring"><path id="tn-seal-ring" d="{ring}" fill="none"/>'
            f'<text font-family="Instrument Sans, system-ui, sans-serif" font-weight="600" font-size="11.5" letter-spacing="1.2" fill="var(--red-deep)">'
            f'<textPath href="#tn-seal-ring" textLength="292" lengthAdjust="spacing">{t("trust.seal")}</textPath></text></g>'
            f'<circle cx="80" cy="80" r="34" fill="var(--red)"/>'
            f'<g transform="translate(55.5 49.5) scale(.5)"><path d="{book}" fill="var(--cream)"/></g></svg>')

TRUST_ICONS = [('signpost', 'gold-light'), ('blocks', 'sky'), ('book', 'blush')]
def trust():
    art = (f'<div class="tn-trust__art tn-scene" data-depth-area aria-hidden="true">'
           f'{layer(6, "top:9%;left:7%;width:15%;--r:-6deg", "<div class=\"tn-tilted\">" + obj("clipboard", "100%") + "</div>")}'
           f'{layer(10, "top:0;left:38%;width:13%", "<div class=\"tn-swing\"><span class=\"tn-trust__cord\"></span>" + obj("bulb", "100%", "tn-glow") + "</div>")}'
           f'<div class="tn-trust__stage"><span class="tn-trust__desk"></span>'
           f'{layer(16, "bottom:16%;left:6%;width:40%", obj("bookstack", "100%"))}'
           f'{layer(22, "bottom:43%;left:12%;width:28%", "<div class=\"tn-hop-idle\">" + obj("owl-prof", "100%") + "</div>")}'
           f'{layer(20, "bottom:16%;left:52%;width:17%", obj("flask", "100%", "tn-bubble"))}'
           f'{layer(26, "bottom:14%;right:4%;width:25%;--r:-14deg", "<div class=\"tn-tilted\">" + obj("magnifier", "100%") + "</div>")}'
           f'</div>'
           f'{layer(18, "top:33%;left:57%;width:10%", "<div class=\"tn-float\">" + obj("bee", "100%") + "</div>", "tn-hide-sm")}'
           f'{layer(30, "top:7%;right:6%;width:31%", seal())}'
           f'</div>')
    pts = ''.join(f'<li class="tn-trust__pt"><span class="tn-trust__ic" style="--c:var(--{c})" aria-hidden="true">{obj(o, "100%")}</span>'
                  f'<span><strong>{t(f"trust.{i}.h")}</strong><span>{t(f"trust.{i}.t")}</span></span></li>' for i, (o, c) in enumerate(TRUST_ICONS, 1))
    return (f'<section class="tn-trust tn-reveal" aria-labelledby="trust-h">{art}'
            f'<div class="tn-trust__body"><h2 class="tn-h2" id="trust-h">{t("trust.h2")}</h2><p class="tn-lead">{t("trust.text")}</p>'
            f'<ul class="tn-trust__pts">{pts}</ul><p class="tn-p"><a class="tn-link tn-link--solo" href="/about">{t("trust.link")}</a></p></div></section>')

# simple, generic glyphs (swap in each platform's official icon from its brand resources if wanted)
SOCIAL_ICON = {
    'instagram': '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8.5 5.5 9.8 3.8h4.4l1.3 1.7H19a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7.5a2 2 0 0 1 2-2z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/><circle cx="12" cy="12.6" r="3.9" fill="none" stroke="currentColor" stroke-width="1.9"/><circle cx="17.6" cy="8.6" r="1" fill="currentColor"/></svg>',
    'tiktok': '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10 17.5V5.2l9-2v11" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/><ellipse cx="7.2" cy="17.6" rx="2.9" ry="2.4" fill="currentColor"/><ellipse cx="16.2" cy="14.3" rx="2.9" ry="2.4" fill="currentColor"/></svg>',
}
def social_links():
    out = ''
    for k in ('instagram', 'tiktok'):
        url = D['social'].get(k)
        if not url: continue
        name = S[f'footer.{k}']
        out += (f'<li><a class="tn-social" href="{E(url)}" rel="me noopener" aria-label="{t("footer.on", name=name)}">{SOCIAL_ICON[k]}'
                f'<span aria-hidden="true">{E(name)}</span></a></li>')
    return out

TADA = [('T', 't'), ('A', 'a'), ('D', 'd'), ('A', 'act')]
def tada():
    steps = ''.join(f'<li class="tn-tada-step tn-reveal{" tn-tada-step--key" if k == "d" else ""}"><span class="tn-tada-step__letter" aria-hidden="true">{l}</span><h3 class="tn-h3">{t(f"tada.{k}.name")}</h3>'
                    f'<p class="tn-tada-step__who">{t(f"tada.{k}.who")}</p><p class="tn-p">{t(f"tada.{k}.text")}</p></li>' for l, k in TADA)
    objs = (f'<div style="right:5%;top:6%;width:96px">{obj("moon", "100%", "tn-float slow")}</div>'
            f'<div style="right:20%;top:9%;width:120px;opacity:.9">{obj("cloud", "100%", "tn-float late")}</div>')
    return (f'<section class="tn-band tn-scene" aria-labelledby="tada-h"><div class="tn-band__objs tn-hide-sm" aria-hidden="true">{objs}</div>'
            f'<div style="position:relative;z-index:1;display:grid;gap:12px"><h2 class="tn-h2" id="tada-h">{t("tada.h2")}</h2><p class="tn-lead">{t("tada.line")}</p></div>'
            f'<ol class="tn-tada">{steps}</ol><div class="tn-tada-foot"><a class="tn-link tn-link--solo" href="/tada">{t("tada.link")}</a></div></section>')

ERR = '<svg viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="9"/><path d="M9 4.5v5.2M9 13.2v.1"/></svg>'
XI = '<svg viewBox="0 0 14 14" aria-hidden="true"><path d="M2 2l10 10M12 2 2 12"/></svg>'
def field(id_, error=None, value=''):
    return (f'<div class="tn-field{" is-error" if error else ""}"><label class="tn-label" for="{id_}">{t("email.label")}</label>'
            f'<input class="tn-input" id="{id_}" name="email" type="email" autocomplete="email" inputmode="email" required aria-invalid="{"true" if error else "false"}" aria-describedby="{id_}-err" value="{E(value)}">'
            f'<p class="tn-error" id="{id_}-err" aria-live="polite">{ERR}<span class="tn-error-text">{E(error or "")}</span></p></div>')

def email_block(id_='news', chip=None, objs=True):
    o = f'<div class="tn-email__obj tn-hide-sm" aria-hidden="true">{obj("plane", 130, "tn-float")}</div>' if objs else ''
    pim = f'<div class="tn-email__pim">{slot("pim-letter.png", "round")}</div>'
    return (f'<section class="tn-email tn-reveal" id="{id_}" aria-labelledby="{id_}-h">{o}<div class="tn-email__head">{pim}<div><h2 class="tn-h2" id="{id_}-h">{t("email.h2")}</h2><p class="tn-p">{t("email.line")}</p></div></div>'
            f'<form class="tn-email__form" novalidate action="#" method="post"><input type="hidden" name="book" value="{chip["key"] if chip else ""}">'
            f'<span class="tn-email__chip{" is-on" if chip else ""}"><span class="tn-email__chip-text">{E(chip["title"]["en"]) if chip else ""}</span><button type="button" aria-label="{t("email.removeBook")}">{XI}</button></span>'
            f'<div class="tn-email__row">{field(id_ + "-email")}<button class="tn-btn" type="submit">{t("email.button")}</button></div>'
            f'<div class="tn-hp" aria-hidden="true"><label for="{id_}-web">Website</label><input id="{id_}-web" name="website" type="text" tabindex="-1" autocomplete="off"></div>'
            f'<p class="tn-small">{t("email.consent")} <a href="/privacy">{t("email.consentLink")}</a></p></form>'
            f'<p class="tn-email__thanks" tabindex="-1" role="status">{t("email.thanks")}</p></section>')

MENU = '<svg viewBox="0 0 18 12" aria-hidden="true"><path d="M1.5 1.5h15M1.5 6h15M1.5 10.5h15"/></svg>'
NAV = [('nav.series', '#series'), ('nav.ages', '#ages'), ('nav.skills', '#skills'), ('nav.grownups', '/guide'), ('nav.about', '/about')]
def header(current=None):
    lock = lockup_svg(badge='var(--red)', book='var(--cream)', ink='var(--ink)', mono=False, inline=True)
    langs = ''.join(f'<li><a href="/" lang="{k}" hreflang="{k}" aria-current="true">{k.upper()}</a></li>' for k, v in D['languages'].items() if v == 'ready')
    links = ''.join(f'<li><a href="{h}"{" aria-current=\"page\"" if current == k else ""}>{t(k)}</a></li>' for k, h in NAV)
    return (f'<header class="tn-header"><div class="tn-wrap tn-header__in"><a class="tn-home" href="/" aria-label="{t("nav.home")}">{lock}</a>'
            f'<ul class="tn-lang" aria-label="{t("nav.language")}">{langs}</ul>'
            f'<button class="tn-menu-btn" type="button" aria-expanded="false" aria-controls="tn-nav">{MENU}{t("nav.menu")}</button>'
            f'<nav class="tn-nav" id="tn-nav" aria-label="{t("nav.main")}"><ul>{links}</ul></nav></div></header>')

FOOT = [('footer.ages', '#ages'), ('footer.series', '#series'), ('footer.skills', '#skills'), ('footer.tada', '/tada'), ('footer.grownups', '/guide'),
        ('footer.send', '/send'), ('footer.howPim', '/pim'), ('footer.about', '/about'), ('footer.teachers', '/teachers'),
        ('footer.privacy', '/privacy'), ('footer.childrensPrivacy', '/childrens-privacy'), ('footer.terms', '/terms')]
def footer():
    lock = lockup_svg(badge='var(--cream)', book='var(--forest)', ink='var(--cream)', mono=False, inline=True)
    links = ''.join(f'<li><a href="{h}">{t(k)}</a></li>' for k, h in FOOT)
    hills = '<svg class="tn-footer__hills" viewBox="0 0 400 40" preserveAspectRatio="none" aria-hidden="true"><path d="M0 40V22C60 6 120 2 190 12s140 14 210-6v34z" fill="var(--forest)"/></svg>'
    walkers = (f'<div class="tn-footer__walk" aria-hidden="true"><div class="tn-footer__hog">{obj("hedgehog", "100%")}</div>'
               f'<div class="tn-footer__snail">{obj("snail", "100%")}</div></div>')
    return (f'<footer class="tn-footer">{hills}{walkers}<div class="tn-wrap tn-footer__in"><div><span class="tn-sr">{E(D["publisher"])}</span>{lock}</div>'
            f'<nav aria-label="{E(D["publisher"])}"><ul>{links}</ul></nav>'
            f'</div><div class="tn-wrap tn-footer__bar"><p class="tn-footer__copy">{t("footer.copyright", year=D["legal"]["copyrightYear"])}</p>'
            f'<div class="tn-footer__social">'
            f'<ul aria-label="{t("footer.social")}">{social_links()}</ul></div></div></footer>')

def head(h2, text, id_):
    return f'<div class="tn-head tn-reveal"><h2 class="tn-h2" id="{id_}">{h2}</h2><p class="tn-lead">{text}</p></div>'

def landing():
    credit = trust() if D["teamCreditOn"] else ''
    return f'''<div class="tn-page" data-dev lang="en">
<a class="tn-skip" href="#main">{t("nav.skip")}</a>
{header()}
<main id="main" tabindex="-1">
<section class="tn-wrap tn-hero" data-depth-area aria-labelledby="hero-h">
  <div class="tn-hero__text">
    <h1 class="tn-h1" id="hero-h">Little stories, growing minds<span class="tn-dot">.</span></h1>
    <p class="tn-lead">{t("hero.text")}</p>
    <div class="tn-actions"><a class="tn-btn" href="#ages">{t("hero.button")}</a><a class="tn-link" href="#skills">{t("hero.link")}</a></div>
  </div>
  {stage()}
</section>
<section class="tn-wrap tn-agesec" aria-labelledby="ages-h" id="ages" tabindex="-1">{age_strip()}</section>
<section class="tn-section" id="series" aria-labelledby="series-h"><div class="tn-wrap">
  {head(t("series.h2"), t("series.text"), "series-h")}
  {worlds()}
</div></section>
<section class="tn-section" id="skills" aria-labelledby="skills-h" tabindex="-1" style="padding-top:0"><div class="tn-wrap">
  {head(t("skills.h2"), t("skills.text"), "skills-h")}
  {skills()}
</div></section>
<div class="tn-wrap">{tada()}</div>
<section class="tn-section" aria-labelledby="send-h"><div class="tn-wrap tn-send">
  <div class="tn-reveal" style="display:grid;gap:16px"><h2 class="tn-h2" id="send-h">{t("send.h2")}</h2><p class="tn-lead">{t("send.text")}</p><p class="tn-p"><a class="tn-link tn-link--solo" href="/send">{t("send.link")}</a></p></div>
  <div class="tn-send__art tn-scene" data-depth-area>
    {slot("story-card-example.png", "4x5")}
    {layer(30, 'top:-14%;right:-14%;width:34%', '<div class="tn-float slow">' + obj('balloon', '100%', 'tn-sway') + '</div>')}
    {layer(40, 'bottom:6%;left:-22%;width:40%', '<div class="tn-float">' + obj('plane', '100%') + '</div>')}
  </div>
</div></section>
<div class="tn-section tn-section--tight"><div class="tn-wrap">{credit}</div></div>
<div class="tn-section"><div class="tn-wrap">{email_block()}</div></div>
</main>
{footer()}
</div>'''

# ======================================================================== preview documents
def preview(group, height, title, body, sub='', width=None, page=False, script='Telning.init(document);', style=''):
    m = f'<!-- @dsCard group="{group}" height={height}' + (f' width={width}' if width else '') + (f' subtitle="{E(sub)}"' if sub else '') + (' page' if page else '') + ' -->'
    st = f'<style>{style}</style>' if style else ''
    return (f'{m}\n<!doctype html>\n<html lang="en">\n<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{E(title)}</title>{st}</head>\n'
            f'<body>\n{body}\n<script>{script}</script>\n</body>\n</html>\n')

def build():
    comps = {}
    lock = lambda **k: lockup_svg(inline=True, **k)
    # Logo
    body = f'''<div class="tn-demo" style="display:grid;gap:24px;align-items:start">
<div style="display:grid;grid-template-columns:1.4fr 1fr;gap:16px">
 <div style="background:var(--paper);border:1px solid var(--ink);border-radius:var(--radius-l);padding:40px;display:grid;place-items:center">{lock(badge='var(--red)', book='var(--cream)', ink='var(--ink)', mono=False).replace('class="tn-lockup"', 'class="tn-lockup" style="width:100%;max-width:440px"')}</div>
 <div style="background:var(--paper);border:1px solid var(--ink);border-radius:var(--radius-l);padding:32px;display:grid;place-items:center">{lock(stacked=True, badge='var(--red)', book='var(--cream)', ink='var(--ink)', mono=False).replace('class="tn-lockup"', 'class="tn-lockup" style="width:200px"')}</div>
</div>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px">
 <div style="background:var(--forest);border-radius:var(--radius-l);padding:32px;display:grid;place-items:center">{lock(badge='var(--cream)', book='var(--forest)', ink='var(--cream)', mono=False).replace('class="tn-lockup"', 'class="tn-lockup" style="width:100%;max-width:280px"')}</div>
 <div style="background:var(--ink);border-radius:var(--radius-l);padding:32px;display:grid;place-items:center">{lock(badge='var(--red)', book='var(--cream)', ink='var(--cream)', mono=False).replace('class="tn-lockup"', 'class="tn-lockup" style="width:100%;max-width:280px"')}</div>
 <div style="background:var(--white);border-radius:var(--radius-l);padding:32px;display:grid;place-items:center;border:1px solid var(--ink)">{lock(badge='var(--ink)', book='var(--white)', ink='var(--ink)', mono=False).replace('class="tn-lockup"', 'class="tn-lockup" style="width:100%;max-width:280px"')}</div>
</div>
<div style="display:flex;gap:28px;align-items:flex-end">''' + ''.join(f'<div>{colophon_svg("var(--red)", "var(--cream)", mono=False, inline=True).replace("class=\"tn-colophon\"", f"class=\"tn-colophon\" style=\"width:{w}px\"")}<span class="tn-demo__label">{w} px</span></div>' for w in (120, 64, 40, 24, 16)) + '''
<p class="tn-small" style="max-width:420px">The colophon: an open book that forms a "T" and a young tree. Smallest: 16 px wide alone, 120 px wide as a lockup. Clear space on every side: the width of the stem times three.</p></div></div>'''
    comps['Logo'] = (preview('Brand', 760, 'Logo', body, 'Lockups, colourways, the colophon'), '''# Logo

The Telning logo: the colophon (an open book that forms a "T" and a young tree, in a rounded red badge) beside "Telning" in Fraunces 600 and "PUBLISHING HOUSE" in Instrument Sans 600 under it. The second line is letter-spaced so it runs exactly from the left edge of "Telning" to its right edge: both lines share the same borders.

- Files: asset group **Logo** (`lockup.svg`, `lockup-stacked.svg`, `lockup-mono.svg`, `colophon.svg`, `colophon-mono.svg`, `favicon.svg`, `favicon-32.png`, `apple-touch-icon.png`, `profile.svg`, `og-image.png`). The words are paths, so no font is needed.
- Colourways: `red` badge + `ink` words on `paper` or `cream` (main); `cream` badge with `forest` book + `cream` words on `forest`; `red` + `cream` on `ink`; one-colour `ink` on `white`. The mono files use `currentColor` with the book cut out.
- The colophon alone works from 16 px. It sits on every book spine and in the corner of every cover.
- Never: recolour the book inside the badge, stretch, add effects, set the name in another font.
''')
    # Objects
    cells = ''
    anim = {'balloon': 'tn-float', 'sun': 'tn-spin', 'rocket': 'tn-flicker tn-float', 'car': 'tn-wheels', 'bulb': 'tn-glow', 'cloud': 'tn-float slow', 'plane': 'tn-float', 'planet': 'tn-float slow', 'heart': 'tn-float', 'bee': 'tn-float', 'bunny': 'tn-hop-idle', 'whale': 'tn-float slow', 'partyballoon': 'tn-float', 'flask': 'tn-bubble'}
    for n in OBJ:
        if n == 'hill': continue
        cells += f'<figure style="margin:0;display:grid;justify-items:center;gap:8px"><div style="height:110px;display:grid;place-items:center">{obj(n, 96, anim.get(n, ""), "max-height:104px;width:auto;height:100%" if n in ("crayon-red","crayon-gold","crayon-sea","crayon-forest","rocket","kite","tulip","tree","bulb","partyballoon","signpost","penguin","bunny","flask","owl-prof","clipboard") else "")}</div><figcaption class="tn-small">{n}</figcaption></figure>'
    body = f'<div style="padding:32px;display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:28px 16px">{cells}</div>'
    comps['Objects'] = (preview('Brand', 1080, 'Objects', body, 'Objects and cute animals, with motion'), '''# Objects

The paper object library: flat paper shapes in a lit, mid and shaded tone, so each one reads with volume. A soft drop shadow lifts it off the page. They are the playful layer of the site: they float, drift, drive and fly.

- Markup: inline SVG with class `tn-obj` and `--w` for its width; built from the colour tokens, so they recolour with the system. Files with fixed colours are in the asset group **Objects**.
- Motion classes: `tn-float` (bob), `tn-sway` (swing from the top), `tn-drift` (cross the stage), `tn-spin` (sun rays), `tn-flicker` (rocket flame), `tn-wheels` (car), `tn-glow` (bulb). All stop under `prefers-reduced-motion`.
- Series emblems: Home & Hearts `house`, Paws & Claws `paw`, Star Hoppers `rocket`, Little Gardeners `tulip`, Big Days `gift`, The Toy Box `blocks`, Little Kitchen `cupcake`, Funny Pages `bubble`, Round the Year `calendar`, Game On `ball`, Everyday Heroes `shield`, On the Move `car`. Skills: Decision intelligence `signpost` (the heart), Emotional intelligence `heart`, Social skills `seesaw`, Behavioural skills `steps`.
- Science desk (the trust block): `owl-prof` (owl in glasses and a cap, reading), `bookstack`, `flask` (bubbles rise: `tn-bubble`), `magnifier`, `clipboard`.
- Animals: fox, bear, bunny, cat, owl, duck, frog, elephant (in a hero cape), penguin, whale, hedgehog, snail, bee. Cute and a little funny: round shapes, dot eyes that blink (`.o-eyes`), ears that wiggle on hover (`.o-ears`), hops (`tn-hop`, `tn-hop-idle`), a peek (`tn-peek`).
- Decoration only: never Pim, a series main character or a book page. Those come from the illustrator, who may also redraw any object or animal in the same size and place.
''')
    # Button and link
    body = (f'<div class="tn-demo"><div><a class="tn-btn" href="#">{t("hero.button")}</a><span class="tn-demo__label">Default</span></div>'
            f'<div><a class="tn-btn is-hover" href="#">{t("hero.button")}</a><span class="tn-demo__label">Hover: lifts, turns forest</span></div>'
            f'<div><a class="tn-btn is-focus" href="#">{t("hero.button")}</a><span class="tn-demo__label">Keyboard focus</span></div>'
            f'<div><a class="tn-link tn-link--solo" href="#">{t("hero.link")}</a><span class="tn-demo__label">Link</span></div>'
            f'<div><a class="tn-link tn-link--solo is-hover" href="#">{t("tada.link")}</a><span class="tn-demo__label">Link hover</span></div></div>')
    comps['Button'] = (preview('Actions', 160, 'Button and link', body), '''# Button

The one main action on a screen: an `ink` pill with `cream` text, Instrument Sans 600 18 px, 56 px tall, `shadow-2`. On hover it lifts 2 px, turns `forest` and takes `shadow-3`.

- Markup: `<a class="tn-btn">` or `<button class="tn-btn">`. Links: `<a class="tn-link">`: `ink` text with a `red` underline that thickens on hover; `tn-link--solo` gives a 48 px target.
- One button per screen; every other action is a link.
- Focus: a 3 px `sea-deep` ring with a 3 px gap, on everything.
''')
    # Pills
    body = (f'<div class="tn-demo"><span class="tn-pill">{t("book.age", min=3, max=5)}</span><span class="tn-pill">Decision intelligence</span><span class="tn-pill tn-pill--dark">{t("book.status.coming")}</span>'
            f'</div>')
    comps['Pill'] = (preview('Actions', 110, 'Pills and chips', body), '''# Pill

Small labels. `tn-pill`: cream with a 1 px ink line (the age of a book, read from its `age`); `tn-pill--dark`: ink with cream text (status: "Coming soon", "Out now"). Use pills only on book cards and book pages; no rows of small facts elsewhere.
''')
    # Book cover and card
    body = '<div class="tn-demo" data-dev style="align-items:flex-start">' + ''.join(f'<div class="tn-tilt" data-tilt="12" style="width:150px">{series_cover(i)}</div>' for i in range(len(SERIES_COVERS))) + '</div>'
    comps['BookCover'] = (preview('Books', 330, 'Book cover', body, 'Hover: 3D tilt'), '''# BookCover

A book cover built from the cover system until the real cover exists. Until the first titles are set, the home page shows one cover per series (Home & Hearts, Star Hoppers, On the Move…; series name as the title): a `cream` cover with a band in the book's colour, the colophon, the series name in small capitals, the two-line title in Fraunces, and the art frame the illustrator fills.

- Markup: `.tn-cover` with `style="--book: var(--red)"` → `.tn-cover__band`, `.tn-colophon.tn-cover__colophon`, `.tn-cover__k`, `.tn-cover__t` (`.tn-cover__l1`, `.tn-cover__l2`), `.tn-cover__art`. Sizes follow the cover width.
- If the book has a `coverImage`, the cover is just that image with alt text.
- Wrap it in `.tn-tilt` to turn it toward the pointer in 3D.
''')
    tpl = dict(l1='Book', l2='Title', colour='red', file='cover-[book].png', kicker='Home & Hearts', title='Book title', age=[3, 5], status='coming', key='template')
    body = '<div class="tn-demo" data-dev style="align-items:flex-start">' + f'<div style="width:220px">{book_card(tpl)}<span class="tn-demo__label">Template: a real book fills it from the site data</span></div>' + '</div>'
    comps['BookCard'] = (preview('Books', 470, 'Book card', body), '''# BookCard

One book in a list: the cover (with tilt), the title, the age pill, the status pill and one link ("Tell me when it's out", or "See it on Amazon" once out). No price, no stars.
''')
    # Age, formats, shelf, skills
    body = f'<div class="tn-page" style="padding:40px 32px">{age_strip()}</div>'
    comps['AgeStrip'] = (preview('Browse', 220, 'Age strip', body, 'Quiet: a quick way in, under the hero', width=1180), '''# AgeStrip

The quick way in by age, kept quiet so the series lead: one heading and three light cards (0–3 Baby and toddler, 3–5 Preschool, 5–7 Early school). Each card has a small coloured disc with the age, the name, and a little animal that hops on hover.

- Markup: `.tn-ages` → `h2.tn-ages__h`, `ul.tn-agestrip > li > a.tn-agechip` with `--c` (disc colour) → `.tn-agechip__n`, `.tn-agechip__l`, `.tn-agechip__obj`.
- Desktop: heading and the three cards in one row. Phones: heading, then the cards stacked.
''')
    body = (f'<div class="tn-demo" data-dev style="align-items:flex-start">{pim_note("pim.hello", "pim-hello.png")}{pim_note("pim.skills", "pim-question.png")}'
            f'{pim_note("pim.send", "pim-card.png", size="tn-pim--sm")}</div>')
    comps['PimNote'] = (preview('Pim', 260, 'Pim note', body, 'Pim speaks for Telning'), '''# PimNote

Pim is the Telning character: the brand's voice. Pim greets visitors, explains, signs the letters and the story cards. Pim is not part of any series.

- Markup: `figure.tn-pim` → `.tn-pim__art` (a round art slot until the illustrator's Pim exists; then an `<img>` with alt "Pim, the Telning character") and `figcaption.tn-pim__bubble` (a hidden "Pim:" for screen readers, then the line). No visible signature: the portrait shows who speaks. Sizes: default, `tn-pim--sm`.
- Pim's voice: first person, warm, short (one sentence, at most 14 words), a little playful, always about choosing. Never a claim, never advice about a child's health.
- Where: the hero greeting, beside the skills, the "send your ending" card, the email block ("Letters from Pim") and every story card.
- Code never draws Pim. Only the illustrator does.
''')
    body = f'<div class="tn-page" style="padding:40px 32px">{worlds()}</div>'
    comps['SeriesWorlds'] = (preview('Browse', 1000, 'Series worlds', body, 'The twelve series: hover a card', width=1180), '''# SeriesWorlds

The star of the home page: the twelve series as little paper worlds. Each card is a scene in its own colour (objects and cute animals standing on a cream paper hill), then the series name in Fraunces and the plain theme word parents search for. On hover the card tilts, the animals hop and wiggle their ears.

- Markup: `ul.tn-worlds > li > a.tn-world.tn-tilt` → `.tn-world__scene` (`--c`; `.tn-world__far`, `.tn-world__o` objects placed by left / bottom / width in %, `.tn-world__ground`) and `.tn-world__body` (`.tn-world__name`, `.tn-world__theme`).
- Four per row on desktop, three on tablets, two on phones.
- Scenes, names and themes come from the site data (`SERIES_SCENES`): Home & Hearts, Paws & Claws, Star Hoppers, Little Gardeners, Big Days, The Toy Box, Little Kitchen, Funny Pages, Round the Year, Game On, Everyday Heroes, On the Move.
- The animals here are decoration. Each series' real main character comes from the illustrator and replaces the scene when ready.
''')
    body = f'<div class="tn-page" style="padding:80px 32px 32px">{skills()}</div>'
    comps['SkillHeart'] = (preview('Skills', 640, 'Skill heart', body, 'Decision intelligence leads; three skills woven in', width=1180), '''# SkillHeart

Telning's difference in one block. Every book brings in all four skills; decision intelligence leads. The big `forest` card holds Decision intelligence with its signpost object (two ways to go); beside it, three cream rows hold the skills woven into every story: Emotional intelligence (heart), Social skills (seesaw), Behavioural skills (steps), and a Pim note.

- Markup: `.tn-skillmap` → `.tn-skillmain.tn-tilt` (`.tn-skillmain__obj`, kicker, `.tn-skillmain__h`, lead) and `.tn-skillside` (kicker, `ul.tn-skillrows > li.tn-skillrow`, PimNote).
- Decision intelligence always comes first and biggest. Describe what the child does; never promise a result ("smarter", "proven", "builds").
''')
    # Stage
    body = f'<div class="tn-page" style="padding:48px"><div data-depth-area style="max-width:620px;margin:auto">{stage()}</div></div>'
    comps['Stage'] = (preview('Layout', 700, 'Hero stage', body, 'The paper theatre: move the pointer over it'), '''# Stage

The hero scene: a paper theatre. Layers of paper hills, clouds, the sun, a tree, a signpost (the choice), three series covers and a driving car sit inside a rounded sky box, with a hopping bunny and a bee; a balloon and blocks float in front of its edges, a fox peeks in from the corner, and Pim greets the visitor from the left. Every layer has a depth (`--d`); `Telning.initDepth()` moves each one by its depth when the pointer moves and when the page scrolls, so the scene feels 3D.

- Markup: `.tn-stage.tn-scene` → `.tn-stage__box` (clipped) with `.tn-layer` children, then unclipped `.tn-layer`s for the objects in front. Put `data-depth-area` on the section that should track the pointer.
- Phones: a shorter stage, fewer objects (`tn-hide-sm`), no pointer depth; gentle motion stays.
- Reduced motion: everything stands still.
''')
    # TADA, art slot, forms
    body = f'<div class="tn-page" style="padding:32px">{tada()}</div>'
    comps['TadaBand'] = (preview('Grown-ups', 640, 'TADA band', body, width=1180), '''# TadaBand

The TADA way for grown-ups on a `forest` band: kicker, heading, one line, the four steps as cream cards with the letter in a `red` circle, the note on dialogic reading and a link. A moon and a cloud float in the corner.
''')
    body = ('<div class="tn-demo" data-dev>' + ''.join(f'<div style="width:{w}px">{slot(f, r)}<span class="tn-demo__label">{r or "1:1"}</span></div>' for f, r, w in
            (('page-story-[book].png', '', 150), ('spread-decide-[book].png', '2x1', 260), ('story-card-example.png', '4x5', 140), ('process-pencils.jpg', '4x3', 200), ('pim-hello.png', 'round', 120))) + '</div>')
    comps['ArtSlot'] = (preview('Layout', 240, 'Art slot', body), '''# ArtSlot

Where the illustrator's art goes: white, 1 px ink line, `radius-m`, a fixed shape (1:1, 2:1, 4:5, 4:3). In development it shows the file name it waits for. Nobody draws into it. The site does not go live with an empty slot.
''')
    body = ('<div class="tn-demo" style="display:grid;grid-template-columns:repeat(3,1fr);align-items:start">'
            f'<div>{field("f1")}</div><div>{field("f2", value="sam@example.com").replace("class=\"tn-input\"", "class=\"tn-input is-focus\"")}</div><div>{field("f3", error=S["email.error.invalid"], value="sam@example")}</div></div>')
    comps['FormField'] = (preview('Forms', 200, 'Form field', body), '''# FormField

Label above; a white pill field 56 px tall with a 1 px ink line. Error: a 2 px `red-deep` line, an icon and words, never colour alone. Real labels only.
''')
    body = f'<div class="tn-page" style="padding:72px 32px 32px">{email_block("demo1")}<div style="height:40px"></div>{email_block("demo2", chip={"key": "star-hoppers", "title": {"en": "Star Hoppers"}}, objs=False)}</div>'
    comps['EmailBlock'] = (preview('Forms', 760, 'Email block', body, 'Default, and opened from a series', width=1000), '''# EmailBlock

"Letters from Pim": the news sign-up on a lifted cream card, with Pim's round portrait (art slot), heading, one line, field, button, consent line with the privacy link. A paper plane floats at its corner. "Tell me when it's out" links open it with that book chosen. Posts JSON to `formEndpoint`; a honeypot field stops spam bots; no cookies.
''')
    body = f'<div class="tn-page" style="min-height:300px">{header()}<div style="height:24px"></div>{header(current="nav.series")}</div>'
    comps['Header'] = (preview('Layout', 260, 'Header', body, width=1280), '''# Header

Sticky, on blurred paper: the lockup (home link), the links Ages · Series · Skills · For grown-ups · About, and the language switch (only languages marked `ready`). Under 1024 px the links open from an `ink` "Menu" button.
''')
    body = f'<div class="tn-page" style="padding-top:60px">{footer()}</div>'
    comps['Footer'] = (preview('Layout', 520, 'Footer', body, width=1280), '''# Footer

A `forest` footer that rises in a soft paper hill, with a hedgehog and a snail walking on top: the cream lockup and twelve links; then a bottom bar with "© 2026 WelloWork AB, Telning Publishing House" (year from `legal.copyrightYear`) and two outlined pill links, Instagram and TikTok (icon + name; screen readers hear "Telning on Instagram").

- The icons are simple generic glyphs (a camera, a music note). Swap in each platform's official icon from its brand resources if wanted; keep the name beside it.
- A link shows only when its URL is set in `social.instagram` / `social.tiktok`.
''')
    body = f'<div class="tn-page" style="padding:40px 32px">{trust()}</div>'
    comps['TrustBand'] = (preview('Grown-ups', 780, 'Made by scientists', body, 'Trust: the science desk and three proof points', width=1180), '''# TrustBand

"Made by scientists, made for play.": the trust block for parents. A lifted cream card: on one side a science desk on graph paper (an owl in glasses and a cap reading a book on a stack of books, a bubbling flask, a magnifier, a clipboard with ticks, a hanging bulb) and the Telning science seal, a red rosette whose ring of words turns slowly; on the other the heading, the team line ("Every Telning book is created by our team of cognitive and behavioural scientists.") and three proof points with small paper icons: Decision intelligence first, Four skills in every book, Made for reading together. One link: "Meet the team".

- Markup: `section.tn-trust` → `.tn-trust__art.tn-scene` (`.tn-trust__desk`, `.tn-layer`s, the `.tn-seal`) and `.tn-trust__body` (H2, lead, `ul.tn-trust__pts > li.tn-trust__pt` with `.tn-trust__ic` (`--c`) and `strong` + `span`, link).
- Desktop: art and words side by side. Phones: art on top (4:3), words under it.
- Only true, approved facts. Never "proven", "science-backed", "clinically tested" or a number from a study. Shown when `teamCreditOn` is true.
''')
    lp = landing()
    comps['LandingPage'] = (preview('Pages', 4000, 'Landing page, desktop', lp, 'Home page · desktop 1280 px', width=1280, page=True), None)
    comps['LandingPagePhone'] = (preview('Pages', 4000, 'Landing page, phone', lp, 'Home page · phone 390 px', width=390, page=True), None)
    return comps

LANDING_README = '''# LandingPage

The home page in the paper-theatre style. Order: header → hero (H1, lead, "Find a book by age", link; the stage with Pim's greeting) → the quiet age strip → Our series (twelve series worlds, the star) → Decision intelligence at the heart (the skill heart) → the TADA band → Send Pim your ending → Made by scientists (the trust block) → Letters from Pim (email) → footer. No kickers, section numbers or rows of small facts.

- Depth: the stage and the story card follow the pointer; cards tilt; spines slide out; objects float, drift, drive and fly; sections rise in as you scroll. Under reduced motion all of it stands still.
- Phones: one column; series in two columns; smaller type (H1 40, H2 28, body 16 px), compact TADA rows, fewer objects.
- Copy marked as draft in the site data needs a person's edit. Art slots wait for the illustrator.
'''

def cover_card():
    return '''<!-- @dsCard height=288 -->
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>Telning</title>
<style>
 html,body{margin:0;height:100%} body{background:var(--paper);color:var(--ink);font-family:var(--font-text);overflow:hidden}
 .cover{position:relative;height:288px;overflow:hidden}
 .art{position:absolute;top:0;left:480px;width:480px;height:288px}
 .art svg{display:block;width:480px;height:288px}
 .red{fill:var(--red)} .forest{fill:var(--forest)} .gold{fill:var(--gold)} .sea{fill:var(--sea-deep)} .blush{fill:var(--blush)} .sky{fill:var(--sky)} .ink{fill:var(--ink)} .cream{fill:var(--cream)}
 .words{position:absolute;left:var(--s6);bottom:var(--s6);max-width:440px}
 .name{margin:0;font-family:var(--font-display);font-weight:600;font-size:112px;line-height:.92;letter-spacing:-.02em}
 .tag{margin:var(--s2) 0 0 4px;font-size:14px;line-height:20px;font-weight:600}
</style></head>
<body><div class="cover"><div class="art" aria-hidden="true">
<svg viewBox="0 0 480 288">
<!--
  blocks      the series colours as book spines: red, forest, gold, sea-deep, blush, sky; one ink ledge; about a third of 960x288
  arrangement a shelf of unequal spines standing on an ink ledge near the bottom, heights stepped like real books, s2 gutters
  pattern     the colophon motif: a cream open-book T on the red spine and a gold sun disc above the shelf; chosen because the brand is a publisher and its mark is a book that grows
  scales      gutters s2 (8); spine corners radius-s/2; ledge 18 px; widths 48–72 in s2 steps
-->
<circle class="gold" cx="380" cy="64" r="44"/>
<rect class="forest" x="24" y="96" width="56" height="164" rx="4"/>
<rect class="red" x="88" y="48" width="72" height="212" rx="4"/>
<path class="cream" d="M124 92c5-5 12-7 18-5l-1 8c-6-1-12 1-17 4v40h-4v-40c-5-3-11-5-17-4l-1-8c6-2 13 0 18 5z"/>
<rect class="gold" x="168" y="120" width="48" height="140" rx="4"/>
<rect class="sea" x="224" y="72" width="64" height="188" rx="4"/>
<rect class="blush" x="296" y="136" width="56" height="124" rx="4"/>
<rect class="sky" x="360" y="112" width="56" height="148" rx="4"/>
<rect class="ink" x="8" y="260" width="472" height="18" rx="3"/>
</svg></div>
<div class="words"><h1 class="name">Telning</h1><p class="tag">Little stories, growing minds.</p></div></div></body></html>
'''

def readme():
    series = ', '.join(f'{x[1]} ({x[2].lower()})' for x in SERIES)
    return f'''Telning Publishing House makes picture books for children from 0 to 7. **Decision intelligence is the heart of every book**: the child sees the choices, thinks about what could happen and picks one. Every book also brings in **emotional intelligence, social skills and behavioural skills**. Decision intelligence is the main focus of the Telning team of scientists and the brand's difference: it leads every page, headline and story. Every book belongs to one **series** (its own world and main character) and fits one **age** (0–3, 3–5, 5–7). **Pim** is the Telning character, the brand's narrator: Pim greets, explains, writes the letters and signs the story cards. Pim belongs to no series.

The look is a **paper theatre**: a premium publisher (Fraunces, warm paper, ink, a red colophon) with playful depth. Flat paper shapes sit in layers with soft shadows; they move a little with the pointer and the scroll; cards tilt; book spines slide out; small objects float, drift, drive and fly.

## Rules

1. **Objects and cute animals, never characters.** Code may draw the paper objects and decorative animals in this system (balloons, cars, blocks, the signpost, the fox, the owl…; animals with simple dot eyes). Never Pim, a series main character or a book page: those come from the human illustrator, through art slots.
2. **Decision intelligence first.** It is named first and shown biggest wherever skills appear. The other three skills sit beside it, never above it.
3. **Pim speaks for Telning.** First person, warm, one short sentence, about choosing. Pim never makes a claim and never gives advice about a child's health.
4. **Safe words only** (see Words). Describe what the child does; never promise a result.
5. **Text on light grounds.** `ink` on `paper`, `cream`, `white`, `blush`, `sky`, `gold`, `gold-light`, `moss`, `rose`; `cream` on `ink`, `forest`, `red`, `red-deep`, `sea-deep`. Never text on `sea` or on an object.
6. **Legal name.** Every page says "Telning Publishing House". The footer's bottom line reads "© 2026 WelloWork AB, Telning Publishing House"; otherwise "WelloWork AB" appears only on Terms, Privacy and the children's privacy notice.
7. **QR pages are clean.** `/guide` and `/send` (printed in the books): no shop links, no prices, none of these words: gift, reward, prize, win, free. Printed addresses never change.
8. **Children's data.** Forms are for grown-ups: first name, age, parent email, the drawing. No photos of children. No cookies, trackers or pixels.
9. **Motion is gentle and optional.** Slow, small, never flashing. Everything stands still under `prefers-reduced-motion`; nothing is hidden if scripts fail.
10. **Placeholders are for building.** The site does not go live with an empty art slot.

## Voice and words

Warm, clear, a little playful; short sentences; no hype, no health words, no big numbers. Say "grown-ups" in headings. The site tagline is "Little stories, growing minds."; the book tagline "Stories your child finishes."

You may use: "Decision intelligence at the heart." · "Every story is built around decision intelligence." · "Your child makes the choices." · "Two endings to choose from, plus a page to draw your own." · "Talk about feelings together." · "Made for talking together." · "Hand-drawn by [name]." · "Screen-free." · "Created by the Telning team of cognitive and behavioural scientists." · "Every Telning book is created by our team of cognitive and behavioural scientists." · "Made by scientists, made for play." · "Decision intelligence is the main focus of our scientists."

Never use: proven, clinically tested, science-backed, makes your child smarter, raises IQ, builds or boosts any skill, boosts vocabulary, builds language skills; calming, reduces anxiety, mindful colouring, stops tantrums; Social Story, therapy, for autism, for ADHD, therapist-approved; the first book of its kind, best, number one, award; any number from a study; treats, cures, medical, diagnosis; TwentyThird, day-23. Say "feelings and life skills", not "SEL", except on `/teachers`.

## Colour

`paper` is the page; `cream` lifts cards and covers; `ink` is text and the main button. `red` is the signature (the colophon, link underlines, TADA letters, accents); `forest` holds the TADA band and the footer; `gold`, `blush`, `sky`, `moss`, `rose` and `sea` give the series and objects their colour. Each colour has lit and shaded tones (`red-light`/`red-deep`, `gold-light`/`gold-deep`, `forest-light`, `sky-light`, `sea-deep`, `paper-deep`) used only to give objects volume.

## Type

Fraunces 600 (`display`) for headings, age numbers, spine names and the wordmark; Fraunces 400 for quiet statements. Instrument Sans 400 and 600 (`text`) for everything else. `display-xl` 96/64/40 px for the H1, `display-l` 60/44/28 px for H2s, `display-m` 26/24/19 px for card headings, `lead` 20/17 px, `body` 18/16 px (desktop/phone), `kicker` 13 px capitals in `red-deep`. Left-aligned. German runs about 30% longer: every box must hold it. Font files live in `fonts/` (SIL Open Font License); never load them from Google.

## Depth, shape, motion

Corners: `radius-l` (28) for big cards, bands and the stage; `radius-m` (16) for TADA cards and slots; `radius-pill` for buttons, fields and pills. Shadows: `shadow-1` small, `shadow-2` cards and covers, `shadow-3` lifted and hover. Objects take a soft drop shadow. Layers carry a depth `--d`: deeper layers move more. Motion uses `move` (220 ms) and `ease`; loops are slow (6–80 s). Focus: a 3 px `sea-deep` ring with a 3 px gap.

## Logo

The colophon (an open book forming a "T" and a young tree, cream in a red rounded badge) with "Telning" in Fraunces 600 and "PUBLISHING HOUSE" in spaced Instrument Sans, set to the exact width of "Telning". Files in the asset group **Logo**. It goes on every spine and every cover.

## Series, ages, skills

Series (with the plain theme word shown under each name, for search): {series}. Names live in the site data and can change; check each for trademarks before print. Ages: 0–3 Baby and toddler, 3–5 Preschool, 5–7 Early school. Skills: Decision intelligence (the heart), then Emotional intelligence, Social skills, Behavioural skills.

## Components

Logo, Objects, PimNote, Button (and link), Pill, BookCover, BookCard, SeriesWorlds, AgeStrip, SkillHeart, Stage, TadaBand, TrustBand, ArtSlot, FormField, EmailBlock, Header, Footer; pages: LandingPage (desktop and phone). Plain HTML with the classes in `components/bundle.css` (prefix `tn-`) and the helpers in `components/bundle.js` (`window.Telning`: `init`, `initDepth`, `initTilt`, `initReveal`, `initMenu`, `initEmail`, `data`, `strings`). No framework.

## Site data and text

`assets/Site data/site-data.json` holds every fact that can change (series, ages, skills, books, links, switches); `strings.en.json` holds all English text (`strings.de.json`, `strings.sv.json` share the keys). A language shows in the switch only when marked `ready`.
'''

if __name__ == '__main__':
    tk = tokens()
    write('tokens.json', json.dumps(tk, indent=2, ensure_ascii=False) + '\n')
    open(os.path.join(OUT, 'tokens.local.css'), 'w').write(tokens_css(tk))
    write('components/bundle.css', open(os.path.join(HERE, 'bundle.css')).read())
    js = open(os.path.join(HERE, 'bundle.js')).read().replace('__DATA__', json.dumps(D, ensure_ascii=False)).replace('__STRINGS__', json.dumps(S, ensure_ascii=False))
    assert '</script' not in js.lower() and '<!--' not in js
    write('components/bundle.js', js)
    comps = build()
    for n, (p, r) in comps.items():
        write(f'components/{n}/preview.html', p)
        write(f'components/{n}/README.md', r if r else (LANDING_README if n == 'LandingPage' else LANDING_README.replace('# LandingPage', '# LandingPagePhone', 1)))
    write('components/Cover/preview.html', cover_card())
    write('README.md', readme())
    write('assets/Site data/README.md', '# Site data\n\nThe facts and text the pages read. Empty values mean "not known yet": hide that part, never show a made-up value.\n\n- `site-data.json`: publisher, taglines, social, switches, languages, ages, formats, skills, the twelve series (name, emblem, colour, status) and the books (empty until the first real titles are set).\n- `strings.en.json`: all English text. `strings.de.json`, `strings.sv.json`: the same keys, empty until a person writes them.\n')
    write('assets/Site data/site-data.json', json.dumps(D, indent=2, ensure_ascii=False) + '\n')
    write('assets/Site data/strings.en.json', json.dumps(S, indent=2, ensure_ascii=False) + '\n')
    for lg in ('de', 'sv'):
        write(f'assets/Site data/strings.{lg}.json', json.dumps({k: '' for k in S}, indent=2) + '\n')
    write('assets/Logo/README.md', '# Logo\n\nThe colophon and lockups. Colour files: `red` badge, `cream` book, `ink` words. `-mono` files: one ink, `currentColor` (black in an `<img>`; inline them and set `color`). The words are paths; no font needed.\n\n- `lockup.svg`, `lockup-stacked.svg`, `lockup-mono.svg`\n- `colophon.svg`, `colophon-mono.svg`\n- `favicon.svg`, `favicon-32.png`, `apple-touch-icon.png` (180 px)\n- `profile.svg` (1080 px, colophon in the middle 70% of the circle)\n- `og-image.png` (1200 × 630, lockup and "Little stories, growing minds.")\n')
    write('assets/Objects/README.md', '# Objects\n\nThe paper object library as files with fixed colours (the pages inline them with colour tokens instead). Objects only: no characters, no faces. The illustrator may redraw any of them in the same size and place.\n')
    print('built', len(comps))
