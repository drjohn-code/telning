"""Telning logo (Direction 2): the colophon (an open book that forms a T and a young tree) + the Fraunces wordmark."""
import os, io, re
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from palette import P

FONTS = '/home/claude/telning/ds2/project/fonts'
def f(v):
    s = f'{v:.2f}'.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s

_fonts = {}
def _font(name):
    if name not in _fonts:
        path = os.path.join(FONTS, name)
        tt = TTFont(path)
        buf = io.BytesIO(); t2 = TTFont(path); t2.flavor = None; t2.save(buf)
        _fonts[name] = (tt, hb.Font(hb.Face(buf.getvalue())))
    return _fonts[name]

def text_path(text, font_file, size, x=0.0, baseline=0.0, letter=0.0):
    tt, hbf = _font(font_file)
    upm = tt['head'].unitsPerEm
    buf = hb.Buffer(); buf.add_str(text); buf.guess_segment_properties()
    hb.shape(hbf, buf, {'kern': True, 'liga': True})
    gs = tt.getGlyphSet(); order = tt.getGlyphOrder(); sc = size / upm
    pen = SVGPathPen(gs, ntos=lambda v: f(v)); cx = 0
    n = len(buf.glyph_infos)
    for i, (info, pos) in enumerate(zip(buf.glyph_infos, buf.glyph_positions)):
        tp = TransformPen(pen, (sc, 0, 0, -sc, x + (cx + pos.x_offset) * sc, baseline - pos.y_offset * sc))
        gs[order[info.codepoint]].draw(tp)
        cx += pos.x_advance + (letter * upm if i < n - 1 else 0)
    return pen.getCommands(), cx * sc

def cap(font_file):
    tt, _ = _font(font_file); return tt['OS/2'].sCapHeight / tt['head'].unitsPerEm

# ---- the colophon, 100 x 130
BADGE = 'M22 0H78A22 22 0 0 1 100 22V108A22 22 0 0 1 78 130H22A22 22 0 0 1 0 108V22A22 22 0 0 1 22 0Z'
BOOK_T = ('M50 50C60 40 74 37 86 40L85 56C73 53 60 56 54.5 61V101.5A4.5 4.5 0 0 1 45.5 101.5V61'
          'C40 56 27 53 15 56L14 40C26 37 40 40 50 50Z')

def colophon_inner(badge, book, mono=False):
    if mono:
        return f'<path fill="{badge}" fill-rule="evenodd" d="{BADGE}{BOOK_T}"/>'
    return f'<path fill="{badge}" d="{BADGE}"/><path fill="{book}" d="{BOOK_T}"/>'

NAME_FONT, PH_FONT = 'Fraunces-600.woff2', 'InstrumentSans-600.woff2'
NAME_SIZE, PH_SIZE, LINE_GAP = 92.0, 23.0, 46.0

def ink_bounds(text, font_file, size, letter=0.0):
    """Left and right ink edges (px) of a shaped line set at x = 0, and the glyph count."""
    from fontTools.pens.boundsPen import BoundsPen
    tt, hbf = _font(font_file); upm = tt['head'].unitsPerEm
    buf = hb.Buffer(); buf.add_str(text); buf.guess_segment_properties(); hb.shape(hbf, buf, {'kern': True, 'liga': True})
    gs = tt.getGlyphSet(); order = tt.getGlyphOrder(); sc = size / upm
    bp = BoundsPen(gs); cx = 0; n = len(buf.glyph_infos)
    for i, (info, pos) in enumerate(zip(buf.glyph_infos, buf.glyph_positions)):
        gs[order[info.codepoint]].draw(TransformPen(bp, (sc, 0, 0, -sc, (cx + pos.x_offset) * sc, -pos.y_offset * sc)))
        cx += pos.x_advance + (letter * upm if i < n - 1 else 0)
    return bp.bounds[0], bp.bounds[2], n

def wordmark_fit():
    """'PUBLISHING HOUSE' is spaced so its ink runs exactly from the left edge of 'Telning' to its right edge."""
    nl, nr, _ = ink_bounds('Telning', NAME_FONT, NAME_SIZE)
    pl, pr, n = ink_bounds('PUBLISHING HOUSE', PH_FONT, PH_SIZE)
    letter = ((nr - nl) - (pr - pl)) / ((n - 1) * PH_SIZE)
    pl, pr, _ = ink_bounds('PUBLISHING HOUSE', PH_FONT, PH_SIZE, letter)
    return nl, nr, pl, letter

def lockup_geo(stacked=False):
    """Geometry in px for a lockup whose colophon is 100 x 130. The two lines share the same left and right edges."""
    nl, nr, pl, letter = wordmark_fit()
    capn = cap(NAME_FONT) * NAME_SIZE; capp = cap(PH_FONT) * PH_SIZE
    if not stacked:
        x0 = 100 + 30.0
        block_h = capn + LINE_GAP + capp
        top = (130 - block_h) / 2
        nb = top + capn
        pb = nb + LINE_GAP + capp
        name_d, _ = text_path('Telning', NAME_FONT, NAME_SIZE, x=x0, baseline=nb)
        ph_d, _ = text_path('PUBLISHING HOUSE', PH_FONT, PH_SIZE, x=x0 + nl - pl, baseline=pb, letter=letter)
        return dict(col_tf='', name=name_d, ph=ph_d, w=x0 + nr + 2, h=130)
    # stacked: colophon centred above the words
    w = max(nr - nl + 4, 100)
    cx = w / 2
    nx = cx - (nl + nr) / 2
    nb = 130 + 34 + capn
    pb = nb + LINE_GAP + capp
    name_d, _ = text_path('Telning', NAME_FONT, NAME_SIZE, x=nx, baseline=nb)
    ph_d, _ = text_path('PUBLISHING HOUSE', PH_FONT, PH_SIZE, x=nx + nl - pl, baseline=pb, letter=letter)
    return dict(col_tf=f'translate({f(cx - 50)} 0)', name=name_d, ph=ph_d, w=w, h=pb + 2)

def lockup_svg(stacked=False, badge='currentColor', book=None, ink='currentColor', mono=True, title='Telning Publishing House', inline=False, cls='tn-lockup'):
    g = lockup_geo(stacked)
    col = colophon_inner(badge, book, mono=mono)
    inner = (f'<g transform="{g["col_tf"]}">{col}</g>' if g['col_tf'] else col) + f'<g fill="{ink}"><path d="{g["name"]}"/><path d="{g["ph"]}"/></g>'
    if inline:
        return f'<svg class="{cls}" viewBox="0 0 {f(g["w"])} {f(g["h"])}" aria-hidden="true" focusable="false">{inner}</svg>'
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {f(g["w"])} {f(g["h"])}" role="img" aria-label="{title}"><title>{title}</title>{inner}</svg>')

def colophon_svg(badge='currentColor', book=None, mono=True, inline=False, cls='tn-colophon'):
    inner = colophon_inner(badge, book, mono)
    if inline:
        return f'<svg class="{cls}" viewBox="0 0 100 130" aria-hidden="true" focusable="false">{inner}</svg>'
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 130" role="img" aria-label="Telning"><title>Telning</title>{inner}</svg>'

def icon_svg(scale=0.72, ground=P['paper'], rounded=True, size=None):
    """Square icon: paper ground, colour colophon centred."""
    s = 130 / scale
    ox, oy = 50 - s / 2, 65 - s / 2
    r = s * 0.2 if rounded else 0
    wh = f' width="{size}" height="{size}"' if size else ''
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{f(ox)} {f(oy)} {f(s)} {f(s)}"{wh}>'
            f'<rect x="{f(ox)}" y="{f(oy)}" width="{f(s)}" height="{f(s)}" rx="{f(r)}" fill="{ground}"/>'
            f'{colophon_inner(P["red"], P["cream"])}</svg>')

def favicon_svg():
    """Favicon: the colophon itself fills the square (it is already a badge)."""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-15 0 130 130"><title>Telning</title>{colophon_inner(P["red"], P["cream"])}</svg>')

def profile_svg():
    # 1080 circle crop: colophon inside the middle 70%
    k = (1080 * 0.70 * 0.86) / 130
    tx = 540 - 50 * k; ty = 540 - 65 * k
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1080" width="1080" height="1080" role="img" aria-label="Telning">'
            f'<rect width="1080" height="1080" fill="{P["paper"]}"/><g transform="translate({f(tx)} {f(ty)}) scale({f(k)})">{colophon_inner(P["red"], P["cream"])}</g></svg>')

def og_svg():
    g = lockup_geo(stacked=False)
    lw = 640.0; k = lw / g['w']; lh = g['h'] * k
    tag_d, tag_w = text_path('Little stories, growing minds.', 'Fraunces-400.woff2', 44)
    block = lh + 54 + 44 * 0.72
    top = (630 - block) / 2
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630" width="1200" height="630" role="img" aria-label="Telning Publishing House. Little stories, growing minds.">'
            f'<rect width="1200" height="630" fill="{P["paper"]}"/>'
            f'<g transform="translate({f((1200 - lw) / 2)} {f(top)}) scale({f(k)})">{colophon_inner(P["red"], P["cream"])}'
            f'<g fill="{P["ink"]}"><path d="{g["name"]}"/><path d="{g["ph"]}"/></g></g>'
            f'<g fill="{P["ink"]}" transform="translate({f((1200 - tag_w) / 2)} {f(top + lh + 54 + 44 * 0.72)})"><path d="{tag_d}"/></g></svg>')
