"""Site data and English text. Lines listed in STRINGS_DRAFT are new drafts a person checks."""

SERIES = [
    # key, series name (brand), theme (plain words people search), emblem object, spine colour, text colour, status
    ('home-hearts', 'Home & Hearts', 'Family & friends', 'house', 'red', 'cream', 'planned'),
    ('paws-claws', 'Paws & Claws', 'Animals', 'paw', 'forest', 'cream', 'planned'),
    ('star-hoppers', 'Star Hoppers', 'Space', 'rocket', 'sea-deep', 'cream', 'planned'),
    ('little-gardeners', 'Little Gardeners', 'Flowers & nature', 'tulip', 'moss', 'ink', 'planned'),
    ('big-days', 'Big Days', 'Celebrations', 'gift', 'gold', 'ink', 'planned'),
    ('toy-box', 'The Toy Box', 'Toys', 'blocks', 'sky', 'ink', 'planned'),
    ('little-kitchen', 'Little Kitchen', 'Food & cooking', 'cupcake', 'blush', 'ink', 'planned'),
    ('funny-pages', 'Funny Pages', 'Cartoons', 'bubble', 'ink', 'cream', 'planned'),
    ('round-the-year', 'Round the Year', 'Months & seasons', 'calendar', 'cream', 'ink', 'planned'),
    ('game-on', 'Game On', 'Sports', 'ball', 'red-deep', 'cream', 'planned'),
    ('everyday-heroes', 'Everyday Heroes', 'Superheroes', 'shield', 'rose', 'ink', 'planned'),
    ('on-the-move', 'On the Move', 'Cars, planes & balloons', 'car', 'gold-light', 'ink', 'planned'),
]
SERIES_NOTES = {'big-days': 'Halloween, Christmas, Easter, Thanksgiving, Midsummer'}

AGES = [('0-3', '0–3', 'Baby and toddler', 'blush'), ('3-5', '3–5', 'Preschool', 'sky'), ('5-7', '5–7', 'Early school', 'gold-light')]

# The heart: decision intelligence. Every book also brings in the other three.
SKILL_MAIN = ('decision', 'Decision intelligence', 'The heart of every Telning book. Your child sees the choices, thinks about what could happen, and picks one.', 'signpost')
SKILLS = [('emotional', 'Emotional intelligence', 'Noticing feelings and naming them.', 'heart'),
          ('social', 'Social skills', 'Sharing, taking turns, making friends.', 'seesaw'),
          ('behavioural', 'Behavioural skills', 'Trying a new way, step by step.', 'steps')]

SITE_DATA = {
    "publisher": "Telning Publishing House",
    "taglineSite": "Little stories, growing minds.",
    "narrator": {"name": "Pim", "role": "The Telning character. Pim speaks for the brand: on the site, in emails and on story cards. Pim is not part of any series."},
    "social": {"handle": "@telning.pub", "hashtag": "#TADAstory", "instagram": "https://www.instagram.com/telning.pub/", "tiktok": "https://www.tiktok.com/@telning.pub"},
    "legal": {"company": "WelloWork AB", "copyrightYear": 2026},
    "illustratorName": "", "teamCreditOn": True, "contactEmail": "", "formEndpoint": "", "guidePdf": "",
    "storyCardReplyTime": "24 hours",
    "languages": {"en": "ready", "de": "draft", "sv": "draft"},
    "ages": [{"key": k, "label": n, "name": l} for k, n, l, _ in AGES],
    "skills": {"main": {"key": SKILL_MAIN[0], "name": SKILL_MAIN[1]},
               "also": [{"key": k, "name": n} for k, n, _, _ in SKILLS],
               "rule": "Every book brings in all four skills. Decision intelligence leads."},
    "series": [{"key": k, "name": n, "theme": th, "emblem": e, "colour": c, "status": st, "note": SERIES_NOTES.get(k, "")}
               for k, n, th, e, c, _, st in SERIES],
    "books": [],
}

S = {
    "nav.skip": "Skip to the main content", "nav.home": "Telning Publishing House, home", "nav.menu": "Menu", "nav.main": "Main", "nav.language": "Language",
    "nav.ages": "Ages", "nav.series": "Series", "nav.skills": "Skills", "nav.grownups": "For grown-ups", "nav.about": "About",
    "hero.h1": "Little stories, growing minds.",
    "hero.text": "Picture books where your child makes the choices. Every story is built around decision intelligence, with emotional intelligence, social skills and behavioural skills woven in.",
    "hero.button": "Find a book by age", "hero.link": "How our books work",
    "pim.hello": "Hi, I’m Pim! In every story, you choose what happens next.",
    "pim.skills": "My favourite question: what would you choose?",
    "pim.send": "Send me your ending. I’ll send you a story card back!",
    "pim.sign": "Pim",
    "pim.alt": "Pim, the Telning character",
    "ages.h2": "Find a book by age", "ages.go": "See the books",
    "series.h2": "Our series", "series.text": "Twelve little worlds, each with its own main character.",
    "series.coming": "Coming soon",
    "book.age": "Ages {min}–{max}", "book.status.coming": "Coming soon", "book.status.out": "Out now",
    "book.amazon": "See it on Amazon", "book.notify": "Tell me when it’s out",
    "skills.h2": "Decision intelligence at the heart",
    "skills.text": "Every book brings in all four skills. Decision intelligence leads: it is the main focus of our scientists.", "skills.main.h": "Decision intelligence",
    "tada.h2": "For grown-ups: the TADA way", "tada.line": "You talk with your child. The child tells the story and makes the choice.",
    "tada.t.name": "Talk", "tada.t.who": "Child", "tada.t.text": "Your child says what they see. You wait, then add one or two words.",
    "tada.a.name": "Ask", "tada.a.who": "Grown-up", "tada.a.text": "One easy question. Then: “What could they do now?”",
    "tada.d.name": "Decide", "tada.d.who": "Child", "tada.d.text": "Your child picks what happens next and says why. No wrong answer.",
    "tada.act.name": "Act", "tada.act.who": "Together", "tada.act.text": "“What would you do?” Try it once in real life.",
    "tada.small": "TADA is the Telning team’s own way to talk about a story, based on dialogic reading.", "tada.link": "Read the TADA way",
    "send.h2": "Send Pim your ending", "send.text": "Your child draws the ending they chose. Take a photo and Pim sends back a story card.",
    "send.small": "For grown-ups. First name and age only. Never a photo of your child.", "send.link": "Send a drawing",
    "trust.h2": "Made by scientists, made for play.",
    "trust.text": "Every Telning book is created by our team of cognitive and behavioural scientists.",
    "trust.1.h": "Decision intelligence first", "trust.1.t": "The main focus of our scientists.",
    "trust.2.h": "Four skills in every book", "trust.2.t": "Decision, emotional, social and behavioural.",
    "trust.3.h": "Made for reading together", "trust.3.t": "The TADA way is based on dialogic reading.",
    "trust.link": "Meet the team", "trust.seal": "COGNITIVE · BEHAVIOURAL · SCIENCE · ",
    "email.h2": "Letters from Pim", "email.line": "Leave your email. Pim writes only when a new book is out.",
    "email.label": "Your email", "email.button": "Sign up", "email.consent": "We use your email only for Telning news.", "email.consentLink": "Read the privacy notice.",
    "email.error.empty": "Please write your email.", "email.error.invalid": "Please check your email address.", "email.sending": "Sending…",
    "email.thanks": "Thank you! Pim will write soon.", "email.removeBook": "Remove", "email.failed": "Sorry, that did not work. Please try again.",
    "footer.ages": "Ages", "footer.series": "Series", "footer.skills": "Skills", "footer.tada": "The TADA way",
    "footer.grownups": "For grown-ups", "footer.send": "Send your ending", "footer.howPim": "Meet Pim", "footer.about": "About",
    "footer.teachers": "For teachers", "footer.privacy": "Privacy", "footer.childrensPrivacy": "Children’s privacy", "footer.terms": "Terms",
    "footer.social": "Telning on social media", "footer.copyright": "© {year} WelloWork AB, Telning Publishing House",
    "footer.instagram": "Instagram", "footer.tiktok": "TikTok", "footer.on": "Telning on {name}",
}
SERIES_SCENES = {
    # series key: (scene colour, [(object, left %, bottom %, width %, motion classes)])
    'home-hearts': ('blush', [('house', 8, 14, 46, ''), ('cat', 56, 12, 30, 'tn-hop'), ('heart', 72, 64, 15, 'tn-float')]),
    'paws-claws': ('moss', [('fox', 2, 10, 34, 'tn-hop'), ('bear', 34, 10, 33, 'tn-hop'), ('bunny', 67, 10, 28, 'tn-hop')]),
    'star-hoppers': ('sea-deep', [('rocket', 8, 18, 17, 'tn-float tn-flicker'), ('planet', 34, 38, 46, 'tn-float slow'), ('moon', 74, 70, 17, 'tn-float late'), ('penguin', 68, 10, 22, 'tn-hop')]),
    'little-gardeners': ('paper-deep', [('tulip', 4, 12, 20, ''), ('tulip', 22, 12, 15, ''), ('snail', 42, 10, 34, 'tn-hop'), ('bee', 66, 56, 24, 'tn-float')]),
    'big-days': ('gold-light', [('gift', 8, 14, 34, 'tn-hop'), ('partyballoon', 46, 34, 13, 'tn-float'), ('partyballoon', 57, 44, 11, 'tn-float late'), ('duck', 66, 10, 30, 'tn-hop')]),
    'toy-box': ('sky', [('blocks', 4, 12, 40, ''), ('ball', 44, 12, 22, 'tn-hop'), ('bear', 66, 10, 29, 'tn-hop')]),
    'little-kitchen': ('rose', [('cupcake', 8, 14, 28, 'tn-hop'), ('apple', 38, 14, 22, 'tn-hop'), ('bunny', 64, 10, 27, 'tn-hop')]),
    'funny-pages': ('gold', [('bubble', 6, 52, 42, 'tn-float'), ('frog', 36, 8, 42, 'tn-hop')]),
    'round-the-year': ('red-light', [('sun', 6, 54, 28, 'tn-spin'), ('kite', 66, 36, 20, 'tn-sway'), ('calendar', 36, 14, 28, ''), ('hedgehog', 2, 8, 32, 'tn-hop')]),
    'game-on': ('forest-light', [('ball', 44, 46, 20, 'tn-float'), ('bunny', 8, 10, 27, 'tn-hop'), ('bear', 64, 10, 29, 'tn-hop')]),
    'everyday-heroes': ('sea', [('shield', 6, 46, 22, 'tn-float'), ('elephant', 32, 8, 42, 'tn-hop'), ('owl', 74, 52, 18, 'tn-float late')]),
    'on-the-move': ('sky-light', [('car', 4, 12, 52, 'tn-wheels'), ('plane', 58, 62, 30, 'tn-float'), ('balloon', 66, 18, 24, 'tn-float slow')]),
}
AGE_ANIMALS = {'0-3': 'duck', '3-5': 'bunny', '5-7': 'owl'}

STRINGS_DRAFT = ["hero.*", "pim.*", "ages.*", "series.*", "skills.*", "tada.a.text", "tada.d.text", "tada.act.text", "tada.line", "send.kicker", "send.text",
                 "trust.*", "footer.copyright", "email.h2", "email.line", "email.button", "email.thanks", "footer.howPim", "nav.*", "email.error.*", "email.sending", "email.failed"]
