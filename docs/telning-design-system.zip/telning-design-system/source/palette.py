"""Telning palette (Direction 2, The Publisher) with tones for layered paper objects."""
P = {
    # base
    'paper': '#F6F1E8', 'paper-deep': '#E9DFCF', 'cream': '#FFFDF8', 'ink': '#16140F', 'ink-soft': '#4A453D',
    # signature
    'red': '#CE4029', 'red-deep': '#A9321D', 'red-light': '#EA7A62',
    'forest': '#1E4A3B', 'forest-light': '#3D6E58', 'moss': '#86A672',
    'gold': '#E8B23A', 'gold-deep': '#B8841A', 'gold-light': '#F6D27E',
    'blush': '#F3C9B8', 'rose': '#E59A82',
    'sky': '#B9D3EC', 'sky-light': '#DDEBF7', 'sea': '#4F7FAE', 'sea-deep': '#2F5C88',
}
