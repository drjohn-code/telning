"""Telning object library: layered paper-cut objects (no characters, no faces).
Each object is flat shapes in light/mid/dark tones so it reads with volume. Depth shadows come from CSS.
`svg(name, mode)` -> inline markup; mode 'var' uses CSS tokens, 'hex' uses fixed colours (for files)."""
import math
from palette import P

def _crescent():
    c1, r1 = (60.0, 62.0), 42.0
    c2, r2 = (82.0, 46.0), 36.0
    d = math.dist(c1, c2)
    a = (r1*r1 - r2*r2 + d*d) / (2*d)
    h = math.sqrt(r1*r1 - a*a)
    ux, uy = (c2[0]-c1[0])/d, (c2[1]-c1[1])/d
    px, py = c1[0] + a*ux, c1[1] + a*uy
    p1 = (px + h*(-uy), py + h*ux); p2 = (px - h*(-uy), py - h*ux)
    f = lambda v: f'{v:.1f}'
    # big arc on C1 from p1 to p2 (the long way), then back along C2 (the short way, inward)
    return f'M{f(p1[0])} {f(p1[1])}A{r1} {r1} 0 1 1 {f(p2[0])} {f(p2[1])}A{r2} {r2} 0 0 0 {f(p1[0])} {f(p1[1])}Z'

def _cube(x, y, s, top, front, side):
    d = s * 0.38
    return (f'<path d="M{x} {y}h{s}l{d} {-d}h{-s}z" fill="{{{top}}}"/>'
            f'<path d="M{x+s} {y}l{d} {-d}v{s}l{-d} {d}z" fill="{{{side}}}"/>'
            f'<rect x="{x}" y="{y}" width="{s}" height="{s}" fill="{{{front}}}"/>')

def _rays(cx, cy, r0, r1, n, fill):
    out = ''
    for i in range(n):
        a = 2*math.pi*i/n
        x0, y0 = cx + r0*math.cos(a), cy + r0*math.sin(a)
        x1, y1 = cx + r1*math.cos(a), cy + r1*math.sin(a)
        out += f'<line x1="{x0:.1f}" y1="{y0:.1f}" x2="{x1:.1f}" y2="{y1:.1f}" stroke="{{{fill}}}" stroke-width="7" stroke-linecap="round"/>'
    return out

OBJ = {}

OBJ['balloon'] = ('0 0 120 130', '''
<path d="M60 6C88 6 104 26 104 48c0 19-20 31-33 40H49C36 79 16 67 16 48 16 26 32 6 60 6z" fill="{red}"/>
<path d="M60 6c11 0 18 21 18 42 0 18-6 30-10 40H52c-4-10-10-22-10-40 0-21 7-42 18-42z" fill="{gold}"/>
<path d="M60 6c28 0 44 20 44 42 0 19-20 31-33 40h-3c4-10 10-22 10-40 0-21-7-42-18-42z" fill="{red-deep}"/>
<path d="M60 6c11 0 18 21 18 42 0 18-6 30-10 40h-4c3-10 7-22 7-40 0-21-5-42-11-42z" fill="{gold-deep}"/>
<ellipse cx="38" cy="32" rx="7" ry="12" transform="rotate(20 38 32)" fill="{cream}" opacity=".35"/>
<path d="M51 88l2 14M69 88l-2 14" stroke="{ink}" stroke-width="2" stroke-linecap="round"/>
<rect x="49" y="100" width="22" height="16" rx="3" fill="{gold-deep}"/>
<rect x="49" y="100" width="22" height="5" rx="2" fill="{red-deep}"/>''')

OBJ['plane'] = ('0 0 120 80', '''
<path d="M6 40 114 8 48 54z" fill="{cream}"/>
<path d="M48 54 114 8 62 74z" fill="{paper-deep}"/>
<path d="M48 54l14 20-4-14z" fill="{rose}"/>
<path d="M6 40 114 8" stroke="{gold}" stroke-width="2" opacity=".7"/>''')

OBJ['car'] = ('0 0 140 90', '''
<path d="M14 54c0-7 4-11 10-12l16-2 14-18c3-3 6-4 10-4h28c4 0 7 2 10 6l12 16 10 2c6 1 10 5 10 12v8c0 3-2 4-4 4H18c-3 0-4-1-4-4z" fill="{red}"/>
<path d="M58 26h32c3 0 5 1 6 4l8 10H48z" fill="{sky-light}"/>
<rect x="72" y="26" width="4" height="14" fill="{red}"/>
<path d="M14 58h118v4c0 3-2 4-4 4H18c-3 0-4-1-4-4z" fill="{red-deep}"/>
<path d="M56 22c2-3 5-4 8-4h26" stroke="{cream}" stroke-width="3" stroke-linecap="round" opacity=".5" fill="none"/>
<circle cx="128" cy="50" r="3.5" fill="{gold-light}"/>
<g class="o-wheel"><circle cx="40" cy="66" r="13" fill="{ink}"/><circle cx="40" cy="66" r="5" fill="{paper-deep}"/><rect x="38.5" y="55" width="3" height="6" rx="1.5" fill="{ink-soft}"/></g>
<g class="o-wheel"><circle cx="106" cy="66" r="13" fill="{ink}"/><circle cx="106" cy="66" r="5" fill="{paper-deep}"/><rect x="104.5" y="55" width="3" height="6" rx="1.5" fill="{ink-soft}"/></g>''')

OBJ['rocket'] = ('0 0 80 140', '''
<g class="o-flame"><path d="M29 94q11 44 22 0z" fill="{gold}"/><path d="M34 94q6 24 12 0z" fill="{gold-light}"/></g>
<path d="M20 70 5 100l17-6zM60 70l15 30-17-6z" fill="{red-deep}"/>
<path d="M40 6c18 16 22 42 20 86H20c-2-44 2-70 20-86z" fill="{cream}"/>
<path d="M40 6c18 16 22 42 20 86h-15c2-42 1-68-5-86z" fill="{paper-deep}"/>
<path d="M40 6c10 9 15 18 17 28H23c2-10 7-19 17-28z" fill="{red}"/>
<path d="M40 6c10 9 15 18 17 28h-9c-1-10-4-19-8-28z" fill="{red-deep}"/>
<circle cx="40" cy="54" r="11" fill="{sea-deep}"/><circle cx="40" cy="54" r="7" fill="{sky}"/><circle cx="37" cy="51" r="2.5" fill="{cream}" opacity=".8"/>
<rect x="20" y="86" width="40" height="8" rx="2" fill="{red}"/>
<rect x="28" y="70" width="4" height="12" rx="2" fill="{ink-soft}" opacity="0"/>''')

OBJ['planet'] = ('0 0 140 110', '''
<g transform="rotate(-16 70 55)">
<path d="M6 57a64 15 0 0 1 128 0" fill="none" stroke="{gold-deep}" stroke-width="6"/>
<circle cx="70" cy="55" r="32" fill="{sea}"/>
<path d="M70 23a32 32 0 0 1 0 64 26 32 0 0 0 0-64z" fill="{sea-deep}"/>
<path d="M40 46c18 4 42 4 60 0" stroke="{sky}" stroke-width="5" fill="none" stroke-linecap="round" opacity=".7"/>
<path d="M42 64c18 4 38 4 56 0" stroke="{sky}" stroke-width="4" fill="none" stroke-linecap="round" opacity=".5"/>
<circle cx="58" cy="38" r="5" fill="{cream}" opacity=".35"/>
<path d="M6 57a64 15 0 0 0 128 0" fill="none" stroke="{gold}" stroke-width="6"/>
</g>''')

OBJ['moon'] = ('0 0 120 120', f'''
<path d="{_crescent()}" fill="{{gold-light}}"/>
<circle cx="36" cy="70" r="5" fill="{{gold}}" opacity=".7"/><circle cx="50" cy="92" r="3.5" fill="{{gold}}" opacity=".7"/><circle cx="30" cy="48" r="3" fill="{{gold}}" opacity=".7"/>''')

OBJ['sun'] = ('0 0 120 120', '<g class="o-rays">' + _rays(60, 60, 38, 52, 12, 'gold-light') + '</g>' + '''
<circle cx="60" cy="60" r="30" fill="{gold}"/>
<path d="M60 30a30 30 0 0 1 0 60 24 30 0 0 0 0-60z" fill="{gold-deep}" opacity=".45"/>
<circle cx="50" cy="48" r="6" fill="{cream}" opacity=".35"/>''')

OBJ['cloud'] = ('0 0 140 80', '''
<circle cx="42" cy="46" r="22" fill="{cream}"/><circle cx="70" cy="34" r="28" fill="{cream}"/><circle cx="100" cy="46" r="20" fill="{cream}"/>
<rect x="22" y="44" width="98" height="26" rx="13" fill="{cream}"/>
<path d="M24 62h94a13 13 0 0 1-12 8H36a13 13 0 0 1-12-8z" fill="{paper-deep}"/>''')

OBJ['blocks'] = ('0 0 130 130', _cube(14, 74, 46, 'red-light', 'red', 'red-deep') + _cube(62, 74, 46, 'sky-light', 'sky', 'sea') +
                  _cube(38, 28, 46, 'gold-light', 'gold', 'gold-deep') + '''
<circle cx="37" cy="97" r="9" fill="{cream}"/><path d="M76 108l9-18 9 18z" fill="{cream}"/><rect x="52" y="42" width="18" height="18" rx="3" fill="{cream}"/>''')

OBJ['ball'] = ('0 0 120 120', '''
<circle cx="60" cy="60" r="44" fill="{cream}"/>
<path d="M60 16c-18 10-24 30-22 44s8 32 22 44c-24 0-44-20-44-44s20-44 44-44z" fill="{red}"/>
<path d="M60 16c18 10 24 30 22 44s-8 32-22 44c24 0 44-20 44-44S84 16 60 16z" fill="{sea}"/>
<path d="M60 16c8 12 10 28 10 44s-2 32-10 44c-8-12-10-28-10-44s2-32 10-44z" fill="{gold}"/>
<path d="M104 60c0 24-20 44-44 44-10 0-19-3-26-9 6 2 12 3 18 3 26 0 46-18 50-42z" fill="{ink}" opacity=".12"/>
<ellipse cx="44" cy="36" rx="8" ry="5" transform="rotate(-35 44 36)" fill="{cream}" opacity=".6"/>''')

def _crayon(main, deep, light):
    return ('0 0 40 150', f'''
<path d="M8 34 20 4l12 30z" fill="{{{deep}}}"/><path d="M16 14l4-10 4 10z" fill="{{{main}}}"/>
<rect x="8" y="34" width="24" height="108" rx="3" fill="{{{main}}}"/>
<rect x="26" y="34" width="6" height="108" rx="2" fill="{{{deep}}}"/>
<rect x="8" y="58" width="24" height="56" fill="{{{light}}}"/>
<rect x="8" y="64" width="24" height="3" fill="{{{deep}}}"/><rect x="8" y="105" width="24" height="3" fill="{{{deep}}}"/>''')
OBJ['crayon-red'] = _crayon('red', 'red-deep', 'red-light')
OBJ['crayon-gold'] = _crayon('gold', 'gold-deep', 'gold-light')
OBJ['crayon-sea'] = _crayon('sea', 'sea-deep', 'sky')
OBJ['crayon-forest'] = _crayon('forest-light', 'forest', 'moss')

OBJ['book'] = ('0 0 160 104', '''
<path d="M80 36C60 24 28 22 4 28v62c24-6 56-4 76 8 20-12 52-14 76-8V28c-24-6-56-4-76 8z" fill="{red-deep}"/>
<path d="M80 32C60 20 30 18 8 24v60c22-6 52-4 72 8z" fill="{cream}"/>
<path d="M80 32c20-12 50-14 72-8v60c-22-6-52-4-72 8z" fill="{paper}"/>
<path d="M80 32v60" stroke="{paper-deep}" stroke-width="3"/>
<circle cx="34" cy="46" r="8" fill="{gold}"/>
<path d="M18 74c10-10 22-14 34-6s16 6 22 2v12c-20-8-38-8-56-4z" fill="{moss}"/>
<path d="M92 72c8-14 18-22 28-18s16-2 22-8v24c-18-4-34-4-50 2z" fill="{sky}"/>
<path d="M118 40l8 14h-16z" fill="{red}"/>''')

OBJ['gift'] = ('0 0 120 120', '''
<rect x="18" y="52" width="84" height="58" rx="4" fill="{red}"/>
<rect x="78" y="52" width="24" height="58" rx="3" fill="{red-deep}"/>
<rect x="12" y="40" width="96" height="18" rx="4" fill="{red-light}"/>
<rect x="53" y="40" width="14" height="70" fill="{gold}"/>
<rect x="53" y="40" width="14" height="18" fill="{gold-light}"/>
<path d="M60 40c-6-16-30-22-30-8 0 10 20 10 30 8zM60 40c6-16 30-22 30-8 0 10-20 10-30 8z" fill="{gold}"/>
<path d="M60 40c-4-8-16-14-20-10M60 40c4-8 16-14 20-10" stroke="{gold-deep}" stroke-width="2" fill="none" stroke-linecap="round"/>
<circle cx="60" cy="40" r="6" fill="{gold-deep}"/>''')

OBJ['cupcake'] = ('0 0 120 130', '''
<path d="M26 70h68l-8 52H34z" fill="{gold}"/>
<path d="M40 70l4 52M54 70l2 52M68 70l-2 52M82 70l-4 52" stroke="{gold-deep}" stroke-width="3"/>
<path d="M86 70l-8 52h8l8-52z" fill="{gold-deep}" opacity=".5"/>
<ellipse cx="60" cy="68" rx="40" ry="12" fill="{rose}"/>
<ellipse cx="60" cy="56" rx="32" ry="12" fill="{blush}"/>
<ellipse cx="60" cy="44" rx="22" ry="10" fill="{rose}"/>
<ellipse cx="60" cy="35" rx="13" ry="7" fill="{blush}"/>
<path d="M60 20c2-6 6-10 12-12" stroke="{forest}" stroke-width="2.5" fill="none" stroke-linecap="round"/>
<circle cx="60" cy="24" r="8" fill="{red}"/><circle cx="57" cy="21" r="2.5" fill="{cream}" opacity=".6"/>''')

OBJ['tulip'] = ('0 0 100 140', '''
<path d="M50 60c2 26 0 50-2 76" stroke="{forest}" stroke-width="6" fill="none" stroke-linecap="round"/>
<path d="M48 120c-24-6-34-26-32-44 18 4 30 20 32 44z" fill="{moss}"/>
<path d="M50 104c20-8 30-26 28-44-16 6-26 22-28 44z" fill="{forest-light}"/>
<path d="M30 22c0 24 8 40 20 40s20-16 20-40c-8 8-14 12-20 12s-12-4-20-12z" fill="{red}"/>
<path d="M50 34c-8 0-12-14-10-30 6 4 10 12 10 20 0-8 4-16 10-20 2 16-2 30-10 30z" fill="{red-light}"/>
<path d="M50 62c12 0 20-16 20-40-4 4-8 7-12 9 0 14-4 26-8 31z" fill="{red-deep}"/>''')

OBJ['tree'] = ('0 0 120 150', '''
<rect x="54" y="88" width="12" height="56" rx="5" fill="{gold-deep}"/>
<circle cx="60" cy="58" r="44" fill="{forest-light}"/>
<path d="M60 14a44 44 0 0 1 0 88 34 44 0 0 0 0-88z" fill="{forest}"/>
<circle cx="44" cy="44" r="10" fill="{moss}" opacity=".7"/>''')

OBJ['house'] = ('0 0 120 120', '''
<rect x="22" y="54" width="76" height="56" fill="{cream}"/>
<rect x="76" y="54" width="22" height="56" fill="{paper-deep}"/>
<rect x="78" y="22" width="12" height="24" fill="{red-deep}"/>
<path d="M12 58 60 18l48 40z" fill="{red}"/><path d="M60 18l48 40H88z" fill="{red-deep}"/>
<rect x="50" y="78" width="20" height="32" rx="10" fill="{forest}"/>
<rect x="30" y="66" width="14" height="14" rx="2" fill="{sky}"/><rect x="82" y="66" width="12" height="14" rx="2" fill="{sea}"/>''')

OBJ['paw'] = ('0 0 120 120', '''
<path d="M60 58c18 0 32 16 32 30 0 12-10 18-20 16-6-1-8-4-12-4s-6 3-12 4c-10 2-20-4-20-16 0-14 14-30 32-30z" fill="{forest}"/>
<ellipse cx="28" cy="52" rx="10" ry="13" transform="rotate(-20 28 52)" fill="{forest-light}"/>
<ellipse cx="46" cy="30" rx="10" ry="14" transform="rotate(-8 46 30)" fill="{forest-light}"/>
<ellipse cx="74" cy="30" rx="10" ry="14" transform="rotate(8 74 30)" fill="{forest-light}"/>
<ellipse cx="92" cy="52" rx="10" ry="13" transform="rotate(20 92 52)" fill="{forest-light}"/>''')

OBJ['bubble'] = ('0 0 130 110', '''
<path d="M20 12h90c8 0 14 6 14 14v44c0 8-6 14-14 14H52L28 104l6-20H20c-8 0-14-6-14-14V26c0-8 6-14 14-14z" fill="{cream}"/>
<path d="M124 50v20c0 8-6 14-14 14H52l-4 4h62c8 0 14-6 14-14z" fill="{paper-deep}"/>
<circle cx="44" cy="48" r="8" fill="{red}"/><circle cx="66" cy="48" r="8" fill="{gold}"/><circle cx="88" cy="48" r="8" fill="{sea}"/>''')

OBJ['calendar'] = ('0 0 120 120', '''
<rect x="14" y="20" width="92" height="88" rx="8" fill="{cream}"/>
<rect x="90" y="20" width="16" height="88" rx="6" fill="{paper-deep}"/>
<path d="M14 28c0-4 4-8 8-8h76c4 0 8 4 8 8v14H14z" fill="{red}"/>
<rect x="34" y="10" width="8" height="20" rx="4" fill="{ink-soft}"/><rect x="78" y="10" width="8" height="20" rx="4" fill="{ink-soft}"/>''' +
    ''.join(f'<rect x="{24+c*16}" y="{52+r*16}" width="10" height="10" rx="2" fill="{{{"gold" if (r, c) == (1, 2) else "paper-deep"}}}"/>' for r in range(3) for c in range(4)))

OBJ['shield'] = ('0 0 110 130', '''
<path d="M55 6l44 14v34c0 32-20 56-44 68C31 110 11 86 11 54V20z" fill="{red}"/>
<path d="M55 6l44 14v34c0 32-20 56-44 68z" fill="{red-deep}"/>
<path d="M62 24 36 70h18l-8 36 28-50H56z" fill="{gold}"/>
<path d="M62 24 56 56h18l-28 50 8-36z" fill="{gold-light}" opacity=".0"/>''')

OBJ['kite'] = ('0 0 110 160', '''
<path d="M55 6l38 44-38 54-38-54z" fill="{sky}"/>
<path d="M55 6l38 44H55z" fill="{sea}"/><path d="M55 50h38l-38 54z" fill="{gold}"/><path d="M17 50h38v54z" fill="{red}"/>
<path d="M55 104c-6 14 8 18 2 30s6 16 2 24" stroke="{ink-soft}" stroke-width="2" fill="none"/>
<path d="M50 120l14-4-4 10zM52 140l14 2-10 8z" fill="{red}"/>''')

OBJ['heart'] = ('0 0 120 110', '''
<path d="M60 102C30 82 10 62 10 38 10 22 22 10 38 10c10 0 18 6 22 14 4-8 12-14 22-14 16 0 28 12 28 28 0 24-20 44-50 64z" fill="{red}"/>
<path d="M60 102c30-20 50-40 50-64 0-16-12-28-28-28 12 6 18 18 16 32-4 28-24 46-38 60z" fill="{red-deep}"/>
<ellipse cx="34" cy="34" rx="9" ry="6" transform="rotate(-35 34 34)" fill="{cream}" opacity=".45"/>''')

OBJ['steps'] = ('0 0 130 120', _cube(10, 82, 30, 'sky-light', 'sky', 'sea') + _cube(44, 62, 30, 'sky-light', 'sky', 'sea') +
                 '<rect x="44" y="92" width="30" height="20" fill="{sky}"/>' + _cube(78, 42, 30, 'sky-light', 'sky', 'sea') +
                 '<rect x="78" y="72" width="30" height="40" fill="{sky}"/>' + '''
<path d="M96 32V6" stroke="{ink-soft}" stroke-width="3" stroke-linecap="round"/><path d="M96 6l20 7-20 7z" fill="{red}"/>''')

OBJ['bulb'] = ('0 0 100 140', '''
<circle cx="50" cy="50" r="46" fill="{gold-light}" opacity=".35" class="o-glow"/>
<path d="M50 10c22 0 36 16 36 36 0 14-8 22-14 30-4 5-6 10-6 16H34c0-6-2-11-6-16-6-8-14-16-14-30 0-20 14-36 36-36z" fill="{gold}"/>
<path d="M50 10c22 0 36 16 36 36 0 14-8 22-14 30-4 5-6 10-6 16h-8c0-8 4-14 8-20 6-8 10-16 10-26 0-18-10-32-26-36z" fill="{gold-deep}" opacity=".55"/>
<path d="M42 92V70l8 8 8-8v22" stroke="{gold-deep}" stroke-width="2.5" fill="none"/>
<rect x="34" y="92" width="32" height="10" rx="3" fill="{ink-soft}"/><rect x="36" y="104" width="28" height="9" rx="3" fill="{ink}"/>
<path d="M42 116h16l-3 8h-10z" fill="{ink-soft}"/>
<ellipse cx="36" cy="34" rx="6" ry="10" transform="rotate(25 36 34)" fill="{cream}" opacity=".5"/>''')

OBJ['seesaw'] = ('0 0 150 100', '''
<path d="M75 54l22 40H53z" fill="{gold}"/><path d="M75 54l22 40H80z" fill="{gold-deep}"/>
<rect x="10" y="48" width="130" height="10" rx="5" fill="{sea}"/>
<rect x="10" y="54" width="130" height="4" rx="2" fill="{sea-deep}"/>
<circle cx="30" cy="32" r="16" fill="{red}"/><path d="M30 16a16 16 0 0 1 0 32 12 16 0 0 0 0-32z" fill="{red-deep}"/>
<circle cx="120" cy="32" r="16" fill="{forest-light}"/><path d="M120 16a16 16 0 0 1 0 32 12 16 0 0 0 0-32z" fill="{forest}"/>''')

OBJ['signpost'] = ('0 0 120 150', '''
<path d="M24 146c8-14 64-14 72 0z" fill="{moss}"/><path d="M60 133c18 0 30 5 36 13H60z" fill="{forest-light}"/>
<rect x="55" y="16" width="10" height="124" rx="3" fill="{gold-deep}"/>
<rect x="60" y="16" width="5" height="124" rx="2" fill="{gold-deep}" opacity=".0"/>
<circle cx="60" cy="14" r="7" fill="{gold}"/>
<path d="M58 30H22L8 44l14 14h36z" fill="{red}"/><path d="M58 48H12l10 10h36z" fill="{red-deep}"/>
<path d="M62 70h36l14 14-14 14H62z" fill="{sea}"/><path d="M62 88h45l-9 10H62z" fill="{sea-deep}"/>
<circle cx="50" cy="44" r="2.6" fill="{cream}" opacity=".8"/><circle cx="70" cy="84" r="2.6" fill="{cream}" opacity=".8"/>''')

OBJ['hill'] = ('0 0 400 120', '<path d="M0 120V70C60 30 120 20 200 40s140 10 200-20v100z" fill="{moss}"/>')

def svg(name, mode='var', cls='', label=None):
    vb, body = OBJ[name]
    fmt = {k: (f'var(--{k})' if mode == 'var' else v) for k, v in P.items()}
    inner = body.format_map(fmt)
    w, h = vb.split()[2:]
    if mode == 'hex':
        return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}" width="{w}" height="{h}">{inner}</svg>'
    c = f' class="{cls}"' if cls else ''
    aria = f' role="img" aria-label="{label}"' if label else ' aria-hidden="true" focusable="false"'
    return f'<svg viewBox="{vb}"{c}{aria}>{inner}</svg>'

SERIES_EMBLEM = {'home-hearts': 'house', 'paws-claws': 'paw', 'star-hoppers': 'rocket', 'little-gardeners': 'tulip', 'big-days': 'gift',
                 'toy-box': 'blocks', 'little-kitchen': 'cupcake', 'funny-pages': 'bubble', 'round-the-year': 'calendar', 'game-on': 'ball',
                 'everyday-heroes': 'shield', 'on-the-move': 'car'}
SKILL_OBJ = {'decision': 'signpost', 'emotional': 'heart', 'social': 'seesaw', 'behavioural': 'steps'}

# ---------------------------------------------------------------- cute animals (decorative, not book characters)
EYE = lambda x, y, r=3.6: (f'<circle cx="{x}" cy="{y}" r="{r}" fill="{{ink}}"/>'
                            f'<circle cx="{x - r * 0.35:.1f}" cy="{y - r * 0.35:.1f}" r="{r * 0.34:.1f}" fill="{{cream}}"/>')
def EYES(*pts, r=3.6):
    return '<g class="o-eyes">' + ''.join(EYE(x, y, r) for x, y in pts) + '</g>'
CHEEK = lambda x, y: f'<ellipse cx="{x}" cy="{y}" rx="5.5" ry="3.2" fill="{{rose}}" opacity=".85"/>'

OBJ['fox'] = ('0 0 120 124', '''
<g class="o-tail"><path d="M80 104c26 2 38-18 30-40-4 14-14 24-28 26z" fill="{red-light}"/><path d="M110 64c3 10-1 18-8 22 5-8 6-14 8-22z" fill="{cream}"/></g>
<ellipse cx="60" cy="98" rx="26" ry="22" fill="{red}"/><ellipse cx="60" cy="104" rx="13" ry="15" fill="{cream}"/>
<path d="M78 98a26 22 0 0 1-18 22 26 22 0 0 0 18-22z" fill="{red-deep}" opacity=".5"/>
<g class="o-ears"><path d="M30 50 31 12l23 26z" fill="{red}"/><path d="M90 50 89 12 66 38z" fill="{red}"/>
<path d="M34 42l1-20 12 14z" fill="{red-deep}"/><path d="M86 42l-1-20-12 14z" fill="{red-deep}"/></g>
<path d="M22 52c0-18 76-18 76 0 0 16-22 32-38 36-16-4-38-20-38-36z" fill="{red}"/>
<path d="M60 88c-9-3-24-12-26-26 11 1 20 5 26 10 6-5 15-9 26-10-2 14-17 23-26 26z" fill="{cream}"/>''' +
    EYES((46, 56), (74, 56), r=4) + '<ellipse cx="60" cy="80" rx="5.5" ry="3.8" fill="{ink}"/>')

OBJ['bear'] = ('0 0 120 124', '''
<g class="o-ears"><circle cx="34" cy="26" r="12" fill="{gold-deep}"/><circle cx="34" cy="26" r="6" fill="{gold-light}"/>
<circle cx="86" cy="26" r="12" fill="{gold-deep}"/><circle cx="86" cy="26" r="6" fill="{gold-light}"/></g>
<ellipse cx="60" cy="98" rx="30" ry="22" fill="{gold-deep}"/><ellipse cx="60" cy="102" rx="18" ry="14" fill="{gold-light}"/>
<ellipse cx="30" cy="94" rx="9" ry="13" transform="rotate(20 30 94)" fill="{gold-deep}"/><ellipse cx="90" cy="94" rx="9" ry="13" transform="rotate(-20 90 94)" fill="{gold-deep}"/>
<circle cx="60" cy="50" r="30" fill="{gold-deep}"/>
<path d="M60 20a30 30 0 0 1 0 60 24 30 0 0 0 0-60z" fill="{ink}" opacity=".08"/>
<ellipse cx="60" cy="60" rx="14" ry="11" fill="{gold-light}"/>
<ellipse cx="60" cy="55" rx="5.5" ry="3.8" fill="{ink}"/>
<path d="M60 59c-1 5-6 6-8 3M60 59c1 5 6 6 8 3" stroke="{ink}" stroke-width="2" fill="none" stroke-linecap="round"/>''' +
    EYES((47, 45), (73, 45)) + CHEEK(40, 58) + CHEEK(80, 58))

OBJ['bunny'] = ('0 0 120 130', '''
<g class="o-ears"><ellipse cx="46" cy="30" rx="10" ry="26" transform="rotate(-8 46 30)" fill="{cream}"/><ellipse cx="46" cy="32" rx="5" ry="18" transform="rotate(-8 46 32)" fill="{blush}"/>
<path d="M68 44c0-18 8-32 18-34 8-1 9 8 2 14-6 5-10 12-12 22z" fill="{cream}"/><path d="M72 40c1-12 6-22 13-25 4 0 4 4 0 8-5 4-8 10-9 17z" fill="{blush}"/></g>
<circle cx="88" cy="108" r="8" fill="{cream}"/>
<ellipse cx="60" cy="102" rx="25" ry="21" fill="{cream}"/><path d="M85 102a25 21 0 0 1-25 21 25 21 0 0 0 25-21z" fill="{paper-deep}"/>
<ellipse cx="48" cy="121" rx="9" ry="5" fill="{paper-deep}"/><ellipse cx="72" cy="121" rx="9" ry="5" fill="{paper-deep}"/>
<ellipse cx="60" cy="64" rx="27" ry="23" fill="{cream}"/>
<path d="M56 70h8l-4 5z" fill="{rose}"/><path d="M60 75c-1 4-5 5-7 3M60 75c1 4 5 5 7 3" stroke="{ink-soft}" stroke-width="1.8" fill="none" stroke-linecap="round"/>''' +
    EYES((49, 62), (71, 62), r=3.4) + CHEEK(42, 72) + CHEEK(78, 72))

OBJ['cat'] = ('0 0 120 124', '''
<g class="o-tail"><path d="M82 108c24 0 28-26 14-32" stroke="{ink-soft}" stroke-width="9" fill="none" stroke-linecap="round"/></g>
<ellipse cx="60" cy="100" rx="24" ry="21" fill="{ink-soft}"/><ellipse cx="60" cy="106" rx="12" ry="13" fill="{paper-deep}"/>
<g class="o-ears"><path d="M34 46 37 14l20 20z" fill="{ink-soft}"/><path d="M86 46 83 14 63 34z" fill="{ink-soft}"/>
<path d="M38 38l2-16 10 10z" fill="{rose}"/><path d="M82 38l-2-16-10 10z" fill="{rose}"/></g>
<ellipse cx="60" cy="56" rx="29" ry="25" fill="{ink-soft}"/>
<ellipse cx="60" cy="68" rx="12" ry="8" fill="{paper-deep}"/>
<g class="o-eyes"><circle cx="47" cy="54" r="5.2" fill="{gold-light}"/><ellipse cx="47" cy="54" rx="1.8" ry="4" fill="{ink}"/>
<circle cx="73" cy="54" r="5.2" fill="{gold-light}"/><ellipse cx="73" cy="54" rx="1.8" ry="4" fill="{ink}"/></g>
<path d="M57 64h6l-3 4z" fill="{rose}"/>
<path d="M30 64l14 2M30 70l14-1M90 64l-14 2M90 70l-14-1" stroke="{paper-deep}" stroke-width="1.6" stroke-linecap="round"/>''')

OBJ['owl'] = ('0 0 120 124', '''
<path d="M30 32 26 8l20 16zM90 32l4-24-20 16z" fill="{sea}"/>
<path d="M60 14c28 0 38 26 38 52 0 30-16 46-38 46S22 96 22 66c0-26 10-52 38-52z" fill="{sea}"/>
<path d="M22 62c-8 16-4 34 8 40-2-14-2-28-8-40zM98 62c8 16 4 34-8 40 2-14 2-28 8-40z" fill="{sea-deep}"/>
<ellipse cx="60" cy="84" rx="22" ry="24" fill="{sky-light}"/>
<path d="M50 76l4 4 4-4M62 76l4 4 4-4M56 88l4 4 4-4" stroke="{sea}" stroke-width="2" fill="none" stroke-linecap="round"/>
<circle cx="44" cy="46" r="15" fill="{cream}"/><circle cx="76" cy="46" r="15" fill="{cream}"/>''' +
    EYES((44, 46), (76, 46), r=7) + '''<path d="M60 54l-6 8 6 8 6-8z" fill="{gold}"/>
<path d="M50 112h8M62 112h8" stroke="{gold}" stroke-width="5" stroke-linecap="round"/>''')

OBJ['duck'] = ('0 0 124 110', '''
<path d="M20 78c0-20 20-26 42-20 14 4 28 2 38-4 4 20-8 44-36 46-24 2-44-4-44-22z" fill="{gold}"/>
<path d="M30 88c8 10 40 12 60 2-10 10-22 12-32 12-14 0-24-6-28-14z" fill="{gold-deep}" opacity=".55"/>
<path d="M34 72c10-8 28-6 34 4-10 8-26 8-34-4z" fill="{gold-deep}"/>
<circle cx="80" cy="38" r="21" fill="{gold}"/>
<path d="M76 18c1-7 8-8 7-1-1 3-4 4-7 1z" fill="{gold}"/>
<path d="M97 40c9-3 18 1 19 6-5 5-14 6-20 3z" fill="{red-light}"/>''' + EYES((86, 34)) + CHEEK(82, 46))

OBJ['frog'] = ('0 0 124 116', '''
<ellipse cx="34" cy="100" rx="14" ry="7" fill="{forest-light}"/><ellipse cx="90" cy="100" rx="14" ry="7" fill="{forest-light}"/>
<ellipse cx="62" cy="80" rx="42" ry="28" fill="{moss}"/>
<ellipse cx="62" cy="94" rx="26" ry="11" fill="{cream}" opacity=".45"/>
<circle cx="38" cy="44" r="17" fill="{moss}"/><circle cx="86" cy="44" r="17" fill="{moss}"/>
<g class="o-eyes"><circle cx="38" cy="42" r="11" fill="{cream}"/><circle cx="86" cy="42" r="11" fill="{cream}"/>
<circle cx="40" cy="44" r="5.5" fill="{ink}"/><circle cx="84" cy="44" r="5.5" fill="{ink}"/>
<circle cx="38" cy="42" r="1.8" fill="{cream}"/><circle cx="82" cy="42" r="1.8" fill="{cream}"/></g>
<path d="M38 74c12 14 36 14 48 0" stroke="{ink}" stroke-width="3" fill="none" stroke-linecap="round"/>''' + CHEEK(32, 70) + CHEEK(92, 70))

OBJ['elephant'] = ('0 0 124 124', '''
<path d="M40 56c-12 26-16 44-20 62h84c-4-18-8-36-20-62z" fill="{red}"/>
<path d="M84 56c12 26 16 44 20 62H86c0-20-4-40-12-60z" fill="{red-deep}"/>
<rect x="44" y="92" width="14" height="26" rx="6" fill="{sky}"/><rect x="66" y="92" width="14" height="26" rx="6" fill="{sky}"/>
<g class="o-ears"><ellipse cx="30" cy="50" rx="21" ry="24" fill="{sky}"/><ellipse cx="32" cy="50" rx="13" ry="16" fill="{blush}"/>
<ellipse cx="94" cy="50" rx="21" ry="24" fill="{sky}"/><ellipse cx="92" cy="50" rx="13" ry="16" fill="{blush}"/></g>
<circle cx="62" cy="48" r="27" fill="{sky}"/>
<path d="M57 60c-2 14 2 22 12 22 7 0 9-7 5-9-4 3-8 0-8-7v-8z" fill="{sky}" stroke="{sea}" stroke-opacity=".25" stroke-width="1"/>
<path d="M62 21a27 27 0 0 1 0 54 21 27 0 0 0 0-54z" fill="{sea}" opacity=".18"/>
<circle cx="62" cy="76" r="4" fill="{gold}"/>''' + EYES((52, 44), (72, 44), r=3.4) + CHEEK(46, 56) + CHEEK(78, 56))

OBJ['penguin'] = ('0 0 110 128', '''
<ellipse cx="40" cy="122" rx="10" ry="4.5" fill="{gold}"/><ellipse cx="70" cy="122" rx="10" ry="4.5" fill="{gold}"/>
<ellipse cx="55" cy="70" rx="34" ry="48" fill="{ink}"/>
<ellipse cx="22" cy="78" rx="8" ry="20" transform="rotate(18 22 78)" fill="{ink-soft}"/><ellipse cx="88" cy="78" rx="8" ry="20" transform="rotate(-18 88 78)" fill="{ink-soft}"/>
<ellipse cx="55" cy="82" rx="23" ry="34" fill="{cream}"/>
<path d="M55 30c14 0 22 8 22 18 0 6-6 10-12 8-4-1-7-3-10-3s-6 2-10 3c-6 2-12-2-12-8 0-10 8-18 22-18z" fill="{cream}"/>
<path d="M50 52h10l-5 8z" fill="{gold}"/>''' + EYES((47, 44), (63, 44), r=3.2) + CHEEK(40, 54) + CHEEK(70, 54))

OBJ['whale'] = ('0 0 124 110', '''
<g class="o-spout"><path d="M54 30c-6-12 2-22 6-8 4-14 14-4 6 8z" fill="{sky-light}"/></g>
<path d="M12 72c0-24 26-36 52-32 22 4 34 18 38 28l12-12c4 10 2 22-4 28l-8-4c-6 14-24 22-46 22-26 0-44-12-44-30z" fill="{sea}"/>
<path d="M18 82c16 16 50 18 76 4-12 10-30 14-44 14-16 0-26-6-32-18z" fill="{sky-light}"/>
<path d="M30 76c4 6 12 6 16 0" stroke="{ink}" stroke-width="2.4" fill="none" stroke-linecap="round"/>''' + EYES((34, 62)) + CHEEK(44, 72))

OBJ['hedgehog'] = ('0 0 124 104', '''
<ellipse cx="58" cy="90" rx="42" ry="12" fill="{paper-deep}"/>
<path d="M16 88 20 66l8 8 2-22 10 12 6-22 8 16 8-20 6 18 10-14 4 18 10-8v20l8-2-2 18z" fill="{gold-deep}"/>
<path d="M28 88l4-12 6 6 4-14 6 10 6-14 6 12 6-12 4 12 8-8v20z" fill="{ink-soft}" opacity=".35"/>
<path d="M82 70c12-4 26 2 32 12-4 8-16 12-28 10z" fill="{cream}"/>
<circle cx="114" cy="82" r="3.6" fill="{ink}"/>
<ellipse cx="72" cy="98" rx="6" ry="3.5" fill="{gold-deep}"/><ellipse cx="94" cy="96" rx="6" ry="3.5" fill="{gold-deep}"/>''' + EYES((97, 77), r=3) + CHEEK(96, 86))

OBJ['snail'] = ('0 0 124 110', '''
<path d="M8 100c20-4 62-4 88 0 8 0 12-6 10-14-2-10-8-12-12-6l-2 16c-22-4-62-4-84 4z" fill="{moss}"/>
<path d="M98 80l-3-20M104 82l5-18" stroke="{moss}" stroke-width="4" stroke-linecap="round"/>
<g class="o-eyes"><circle cx="95" cy="58" r="4" fill="{ink}"/><circle cx="109" cy="62" r="4" fill="{ink}"/></g>
<circle cx="54" cy="68" r="28" fill="{gold}"/>
<path d="M54 68m-4 0a4 4 0 1 1 8 0a10 10 0 1 1-20 0a16 16 0 1 1 32 0a22 22 0 1 1-44 0" stroke="{gold-deep}" stroke-width="4" fill="none" stroke-linecap="round"/>
<path d="M100 90c3 3 7 3 9 0" stroke="{ink}" stroke-width="2" fill="none" stroke-linecap="round"/>''')

OBJ['bee'] = ('0 0 120 110', '''
<g class="o-wings"><ellipse cx="52" cy="32" rx="14" ry="20" transform="rotate(-22 52 32)" fill="{sky-light}" opacity=".95"/>
<ellipse cx="72" cy="30" rx="14" ry="20" transform="rotate(22 72 30)" fill="{sky-light}" opacity=".95"/></g>
<ellipse cx="62" cy="66" rx="34" ry="26" fill="{gold}"/>
<path d="M54 41c-6 14-6 36 0 50h9c-6-14-6-36 0-50zM74 42c-5 14-5 34 0 48l8-4c-4-12-4-28 0-40z" fill="{ink}"/>
<path d="M96 62l12 4-12 6z" fill="{ink}"/>
<path d="M34 46c-4-10-10-14-16-12M40 42c0-10-4-16-10-16" stroke="{ink}" stroke-width="2.4" fill="none" stroke-linecap="round"/>
<circle cx="18" cy="34" r="3" fill="{ink}"/><circle cx="30" cy="26" r="3" fill="{ink}"/>
<path d="M34 74c4 4 9 4 12 0" stroke="{ink}" stroke-width="2.2" fill="none" stroke-linecap="round"/>''' + EYES((40, 62), r=3.4) + CHEEK(36, 70))

OBJ['partyballoon'] = ('0 0 80 150', '''
<path d="M40 86c-4 14 6 22 0 36s4 20 0 26" stroke="{ink-soft}" stroke-width="1.6" fill="none"/>
<ellipse cx="40" cy="44" rx="30" ry="38" fill="{red}"/><path d="M40 6a30 38 0 0 1 0 76 22 38 0 0 0 0-76z" fill="{red-deep}" opacity=".45"/>
<path d="M35 82h10l-5 7z" fill="{red-deep}"/><ellipse cx="28" cy="28" rx="6" ry="10" transform="rotate(25 28 28)" fill="{cream}" opacity=".45"/>''')

OBJ['apple'] = ('0 0 110 120', '''
<path d="M55 30c-4-10-2-20 4-24" stroke="{ink-soft}" stroke-width="4" fill="none" stroke-linecap="round"/>
<path d="M58 20c8-12 26-12 30-4-8 10-22 10-30 4z" fill="{moss}"/>
<path d="M55 34c-16-10-44-6-44 26 0 30 22 54 44 50 22 4 44-20 44-50 0-32-28-36-44-26z" fill="{red}"/>
<path d="M55 34c16-10 44-6 44 26 0 30-22 54-44 50 18-6 32-26 32-50 0-20-14-30-32-26z" fill="{red-deep}" opacity=".45"/>
<ellipse cx="32" cy="56" rx="7" ry="12" transform="rotate(20 32 56)" fill="{cream}" opacity=".4"/>''')

# ---------------------------------------------------------------- the science desk (trust section)
OBJ['owl-prof'] = ('0 0 120 132', '''
<path d="M60 22c28 0 38 26 38 52 0 30-16 46-38 46S22 104 22 74c0-26 10-52 38-52z" fill="{sea}"/>
<path d="M22 70c-8 16-4 34 8 40-2-14-2-28-8-40zM98 70c8 16 4 34-8 40 2-14 2-28 8-40z" fill="{sea-deep}"/>
<ellipse cx="60" cy="92" rx="22" ry="24" fill="{sky-light}"/>
<circle cx="44" cy="54" r="15" fill="{cream}"/><circle cx="76" cy="54" r="15" fill="{cream}"/>''' +
    EYES((45, 55), (75, 55), r=6.5) + '''
<g fill="none" stroke="{ink}" stroke-width="3"><circle cx="44" cy="54" r="16"/><circle cx="76" cy="54" r="16"/><path d="M58 52c1-3 3-3 4 0"/></g>
<path d="M60 64l-6 8 6 8 6-8z" fill="{gold}"/>
<path d="M36 22c0-6 48-6 48 0v8c-6-3-42-3-48 0z" fill="{ink-soft}"/>
<path d="M60 2 104 14 60 26 16 14z" fill="{ink}"/>
<path d="M60 14 92 16v16" stroke="{gold}" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M88 30h8l-1 10h-6z" fill="{gold}"/>
<path d="M30 112c10-8 22-8 30-2 8-6 20-6 30 2v14c-10-6-22-6-30 0-8-6-20-6-30 0z" fill="{red}"/>
<path d="M33 110c9-6 19-6 27-1v14c-8-5-18-5-27 0zM60 109c8-5 18-5 27 1v13c-9-5-19-5-27 0z" fill="{cream}"/>
<path d="M60 109v14" stroke="{paper-deep}" stroke-width="2"/>''')

OBJ['flask'] = ('0 0 100 140', '''
<g class="o-bubbles"><circle cx="46" cy="18" r="5" fill="{sky-light}"/><circle cx="58" cy="8" r="3.5" fill="{sky-light}"/><circle cx="52" cy="-2" r="2.5" fill="{sky-light}"/></g>
<path d="M38 30h24v26l26 58c4 9-2 18-12 18H24c-10 0-16-9-12-18l26-58z" fill="{cream}" opacity=".92"/>
<path d="M27 88h46l15 26c4 9-2 18-12 18H24c-10 0-16-9-12-18z" fill="{moss}"/>
<path d="M62 88h11l15 26c4 9-2 18-12 18H66c8 0 12-9 8-18z" fill="{forest-light}"/>
<circle cx="40" cy="108" r="5" fill="{cream}" opacity=".7"/><circle cx="54" cy="98" r="3.5" fill="{cream}" opacity=".7"/><circle cx="60" cy="116" r="2.5" fill="{cream}" opacity=".7"/>
<rect x="34" y="24" width="32" height="9" rx="4" fill="{paper-deep}"/>
<path d="M42 40v18L22 104" stroke="{cream}" stroke-width="4" fill="none" stroke-linecap="round" opacity=".8"/>''')

OBJ['magnifier'] = ('0 0 120 120', '''
<path d="M72 72l34 34" stroke="{ink-soft}" stroke-width="14" stroke-linecap="round"/>
<path d="M76 76l28 28" stroke="{red-deep}" stroke-width="8" stroke-linecap="round"/>
<circle cx="48" cy="48" r="34" fill="{sky-light}" opacity=".75"/>
<circle cx="48" cy="48" r="34" fill="none" stroke="{gold-deep}" stroke-width="10"/>
<path d="M28 40a22 22 0 0 1 16-16" stroke="{cream}" stroke-width="5" fill="none" stroke-linecap="round"/>''')

OBJ['clipboard'] = ('0 0 100 124', '''
<rect x="8" y="12" width="84" height="108" rx="8" fill="{gold-deep}"/>
<rect x="16" y="22" width="68" height="90" rx="3" fill="{cream}"/>
<rect x="34" y="6" width="32" height="16" rx="5" fill="{ink-soft}"/>
<g stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M24 44l5 5 9-10M24 68l5 5 9-10M24 92l5 5 9-10" stroke="{red}" stroke-width="4"/>
<path d="M46 46h28M46 70h24M46 94h28" stroke="{paper-deep}" stroke-width="5"/></g>''')

OBJ['bookstack'] = ('0 0 150 96', '''
<rect x="6" y="66" width="138" height="26" rx="4" fill="{red}"/><rect x="118" y="70" width="22" height="18" rx="2" fill="{cream}"/>
<rect x="6" y="84" width="138" height="8" rx="3" fill="{red-deep}"/><rect x="24" y="66" width="8" height="26" fill="{gold}"/>
<rect x="18" y="40" width="116" height="26" rx="4" fill="{sea-deep}"/><rect x="108" y="44" width="22" height="18" rx="2" fill="{cream}"/>
<rect x="34" y="40" width="8" height="26" fill="{sky}"/>
<g transform="rotate(-3 76 26)"><rect x="12" y="14" width="124" height="26" rx="4" fill="{gold}"/><rect x="112" y="18" width="20" height="18" rx="2" fill="{cream}"/>
<rect x="12" y="32" width="124" height="8" rx="3" fill="{gold-deep}"/><rect x="28" y="14" width="8" height="26" fill="{red}"/></g>''')

ANIMALS = ['fox', 'bear', 'bunny', 'cat', 'owl', 'owl-prof', 'duck', 'frog', 'elephant', 'penguin', 'whale', 'hedgehog', 'snail', 'bee']
