import sys, os
from playwright.sync_api import sync_playwright
P = '/home/claude/telning/ds2/project'; OUT = '/home/claude/telning/out2'
def frame_html(name, body_override=None, reveal_all=True):
    src = open(f'{P}/components/{name}/preview.html').read()
    pre = (f'<style>{open(OUT + "/tokens.local.css").read()}</style><style>{open(P + "/components/bundle.css").read()}</style>'
           f'<script>{open(P + "/components/bundle.js").read()}</script>')
    src = src.replace('<head>', '<head>' + pre, 1).replace('<html lang="en">', '<html lang="en" data-theme="light">', 1)
    if body_override: src = body_override(src)
    path = f'{OUT}/frame-{name}.html'; open(path, 'w').write(src); return path
def shot(pg, name, width, height=900, out=None, settle=600):
    path = frame_html(name)
    pg.set_viewport_size({'width': width, 'height': height}); pg.goto('file://' + path); pg.wait_for_timeout(settle)
    pg.evaluate("document.querySelectorAll('.tn-reveal').forEach(e=>e.classList.add('is-in'))"); pg.wait_for_timeout(800)
    pg.screenshot(path=out or f'{OUT}/{name}-{width}.png', full_page=True)
if __name__ == '__main__':
    with sync_playwright() as pw:
        b = pw.chromium.launch(); pg = b.new_page()
        for spec in sys.argv[1:]:
            n, w = spec.split(':'); shot(pg, n, int(w))
        b.close()
