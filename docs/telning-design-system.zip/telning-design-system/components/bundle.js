/* Telning — small vanilla helpers: depth (parallax), tilt, reveal, phone menu, email block. No framework. */
(function () {
  var T = window.Telning = window.Telning || {};
  T.data = {"publisher": "Telning Publishing House", "taglineSite": "Little stories, growing minds.", "narrator": {"name": "Pim", "role": "The Telning character. Pim speaks for the brand: on the site, in emails and on story cards. Pim is not part of any series."}, "social": {"handle": "@telning.pub", "hashtag": "#TADAstory", "instagram": "https://www.instagram.com/telning.pub/", "tiktok": "https://www.tiktok.com/@telning.pub"}, "legal": {"company": "WelloWork AB", "copyrightYear": 2026}, "illustratorName": "", "teamCreditOn": true, "contactEmail": "", "formEndpoint": "", "guidePdf": "", "storyCardReplyTime": "24 hours", "languages": {"en": "ready", "de": "draft", "sv": "draft"}, "ages": [{"key": "0-3", "label": "0–3", "name": "Baby and toddler"}, {"key": "3-5", "label": "3–5", "name": "Preschool"}, {"key": "5-7", "label": "5–7", "name": "Early school"}], "skills": {"main": {"key": "decision", "name": "Decision intelligence"}, "also": [{"key": "emotional", "name": "Emotional intelligence"}, {"key": "social", "name": "Social skills"}, {"key": "behavioural", "name": "Behavioural skills"}], "rule": "Every book brings in all four skills. Decision intelligence leads."}, "series": [{"key": "home-hearts", "name": "Home & Hearts", "theme": "Family & friends", "emblem": "house", "colour": "red", "status": "planned", "note": ""}, {"key": "paws-claws", "name": "Paws & Claws", "theme": "Animals", "emblem": "paw", "colour": "forest", "status": "planned", "note": ""}, {"key": "star-hoppers", "name": "Star Hoppers", "theme": "Space", "emblem": "rocket", "colour": "sea-deep", "status": "planned", "note": ""}, {"key": "little-gardeners", "name": "Little Gardeners", "theme": "Flowers & nature", "emblem": "tulip", "colour": "moss", "status": "planned", "note": ""}, {"key": "big-days", "name": "Big Days", "theme": "Celebrations", "emblem": "gift", "colour": "gold", "status": "planned", "note": "Halloween, Christmas, Easter, Thanksgiving, Midsummer"}, {"key": "toy-box", "name": "The Toy Box", "theme": "Toys", "emblem": "blocks", "colour": "sky", "status": "planned", "note": ""}, {"key": "little-kitchen", "name": "Little Kitchen", "theme": "Food & cooking", "emblem": "cupcake", "colour": "blush", "status": "planned", "note": ""}, {"key": "funny-pages", "name": "Funny Pages", "theme": "Cartoons", "emblem": "bubble", "colour": "ink", "status": "planned", "note": ""}, {"key": "round-the-year", "name": "Round the Year", "theme": "Months & seasons", "emblem": "calendar", "colour": "cream", "status": "planned", "note": ""}, {"key": "game-on", "name": "Game On", "theme": "Sports", "emblem": "ball", "colour": "red-deep", "status": "planned", "note": ""}, {"key": "everyday-heroes", "name": "Everyday Heroes", "theme": "Superheroes", "emblem": "shield", "colour": "rose", "status": "planned", "note": ""}, {"key": "on-the-move", "name": "On the Move", "theme": "Cars, planes & balloons", "emblem": "car", "colour": "gold-light", "status": "planned", "note": ""}], "books": []};
  T.strings = { en: {"nav.skip": "Skip to the main content", "nav.home": "Telning Publishing House, home", "nav.menu": "Menu", "nav.main": "Main", "nav.language": "Language", "nav.ages": "Ages", "nav.series": "Series", "nav.skills": "Skills", "nav.grownups": "For grown-ups", "nav.about": "About", "hero.h1": "Little stories, growing minds.", "hero.text": "Picture books where your child makes the choices. Every story is built around decision intelligence, with emotional intelligence, social skills and behavioural skills woven in.", "hero.button": "Find a book by age", "hero.link": "How our books work", "pim.hello": "Hi, I’m Pim! In every story, you choose what happens next.", "pim.skills": "My favourite question: what would you choose?", "pim.send": "Send me your ending. I’ll send you a story card back!", "pim.sign": "Pim", "pim.alt": "Pim, the Telning character", "ages.h2": "Find a book by age", "ages.go": "See the books", "series.h2": "Our series", "series.text": "Twelve little worlds, each with its own main character.", "series.coming": "Coming soon", "book.age": "Ages {min}–{max}", "book.status.coming": "Coming soon", "book.status.out": "Out now", "book.amazon": "See it on Amazon", "book.notify": "Tell me when it’s out", "skills.h2": "Decision intelligence at the heart", "skills.text": "Every book brings in all four skills. Decision intelligence leads: it is the main focus of our scientists.", "skills.main.h": "Decision intelligence", "tada.h2": "For grown-ups: the TADA way", "tada.line": "You talk with your child. The child tells the story and makes the choice.", "tada.t.name": "Talk", "tada.t.who": "Child", "tada.t.text": "Your child says what they see. You wait, then add one or two words.", "tada.a.name": "Ask", "tada.a.who": "Grown-up", "tada.a.text": "One easy question. Then: “What could they do now?”", "tada.d.name": "Decide", "tada.d.who": "Child", "tada.d.text": "Your child picks what happens next and says why. No wrong answer.", "tada.act.name": "Act", "tada.act.who": "Together", "tada.act.text": "“What would you do?” Try it once in real life.", "tada.small": "TADA is the Telning team’s own way to talk about a story, based on dialogic reading.", "tada.link": "Read the TADA way", "send.h2": "Send Pim your ending", "send.text": "Your child draws the ending they chose. Take a photo and Pim sends back a story card.", "send.small": "For grown-ups. First name and age only. Never a photo of your child.", "send.link": "Send a drawing", "trust.h2": "Made by scientists, made for play.", "trust.text": "Every Telning book is created by our team of cognitive and behavioural scientists.", "trust.1.h": "Decision intelligence first", "trust.1.t": "The main focus of our scientists.", "trust.2.h": "Four skills in every book", "trust.2.t": "Decision, emotional, social and behavioural.", "trust.3.h": "Made for reading together", "trust.3.t": "The TADA way is based on dialogic reading.", "trust.link": "Meet the team", "trust.seal": "COGNITIVE · BEHAVIOURAL · SCIENCE · ", "email.h2": "Letters from Pim", "email.line": "Leave your email. Pim writes only when a new book is out.", "email.label": "Your email", "email.button": "Sign up", "email.consent": "We use your email only for Telning news.", "email.consentLink": "Read the privacy notice.", "email.error.empty": "Please write your email.", "email.error.invalid": "Please check your email address.", "email.sending": "Sending…", "email.thanks": "Thank you! Pim will write soon.", "email.removeBook": "Remove", "email.failed": "Sorry, that did not work. Please try again.", "footer.ages": "Ages", "footer.series": "Series", "footer.skills": "Skills", "footer.tada": "The TADA way", "footer.grownups": "For grown-ups", "footer.send": "Send your ending", "footer.howPim": "Meet Pim", "footer.about": "About", "footer.teachers": "For teachers", "footer.privacy": "Privacy", "footer.childrensPrivacy": "Children’s privacy", "footer.terms": "Terms", "footer.social": "Telning on social media", "footer.copyright": "© {year} WelloWork AB, Telning Publishing House", "footer.instagram": "Instagram", "footer.tiktok": "TikTok", "footer.on": "Telning on {name}"} };
  function each(root, sel, fn) { Array.prototype.forEach.call((root || document).querySelectorAll(sel), fn); }
  function s(k) { return (T.strings.en && T.strings.en[k]) || ''; }
  var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia && window.matchMedia('(pointer: fine)').matches;

  /* Depth: layers inside .tn-scene move with the pointer (desktop) and with the scroll */
  T.initDepth = function (root) {
    if (calm) return;
    each(root, '.tn-scene', function (scene) {
      var raf = 0, px = 0, py = 0;
      function apply() { raf = 0; scene.style.setProperty('--px', px.toFixed(3)); scene.style.setProperty('--py', py.toFixed(3)); }
      if (finePointer) {
        (scene.closest('[data-depth-area]') || scene).addEventListener('pointermove', function (e) {
          var r = scene.getBoundingClientRect();
          px = ((e.clientX - r.left) / r.width - 0.5) * 2; py = ((e.clientY - r.top) / r.height - 0.5) * 2;
          if (!raf) raf = requestAnimationFrame(apply);
        });
        (scene.closest('[data-depth-area]') || scene).addEventListener('pointerleave', function () { px = 0; py = 0; if (!raf) raf = requestAnimationFrame(apply); });
      }
      /* scroll depth only in a normal browser window (not in a frame that is as tall as the page) */
      if (window.innerHeight > 1600) return;
      function onScroll() {
        var r = scene.getBoundingClientRect(), off = (r.top + r.height / 2) - window.innerHeight / 2;
        off = Math.max(-500, Math.min(500, off));
        scene.style.setProperty('--sy', Math.round(off));
      }
      window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
    });
  };

  /* Tilt: cards turn a little toward the pointer */
  T.initTilt = function (root) {
    if (calm || !finePointer) return;
    each(root, '.tn-tilt', function (el) {
      var max = parseFloat(el.getAttribute('data-tilt') || '8');
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        el.style.setProperty('--ry', (x * max).toFixed(2) + 'deg'); el.style.setProperty('--rx', (-y * max).toFixed(2) + 'deg');
      });
      el.addEventListener('pointerleave', function () { el.style.setProperty('--ry', '0deg'); el.style.setProperty('--rx', '0deg'); });
    });
  };

  /* Reveal on scroll (never leaves content hidden: everything shows after 2.5 s) */
  T.initReveal = function (root) {
    var items = (root || document).querySelectorAll('.tn-reveal');
    function showAll() { Array.prototype.forEach.call(items, function (el) { el.classList.add('is-in'); }); }
    if (calm || !('IntersectionObserver' in window)) { showAll(); return; }
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } }); }, { rootMargin: '0px 0px -8% 0px' });
    Array.prototype.forEach.call(items, function (el) { io.observe(el); });
    setTimeout(showAll, 2500);
  };

  T.initMenu = function (root) {
    each(root, '.tn-menu-btn', function (btn) {
      var nav = document.getElementById(btn.getAttribute('aria-controls'));
      btn.addEventListener('click', function () {
        var open = btn.getAttribute('aria-expanded') !== 'true';
        btn.setAttribute('aria-expanded', String(open)); nav.classList.toggle('is-open', open);
      });
    });
  };

  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  T.initEmail = function (root) {
    each(root, '.tn-email', function (block) {
      var form = block.querySelector('form'), field = block.querySelector('.tn-field'), input = block.querySelector('input[type="email"]');
      var err = block.querySelector('.tn-error-text'), btn = block.querySelector('.tn-btn'), chip = block.querySelector('.tn-email__chip');
      var bookInput = block.querySelector('input[name="book"]');
      function setError(m) { field.classList.toggle('is-error', !!m); input.setAttribute('aria-invalid', m ? 'true' : 'false'); err.textContent = m || ''; }
      input.addEventListener('input', function () { if (field.classList.contains('is-error') && EMAIL_RE.test(input.value.trim())) setError(''); });
      if (chip) chip.querySelector('button').addEventListener('click', function () { bookInput.value = ''; chip.classList.remove('is-on'); input.focus(); });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var v = input.value.trim();
        if (!v) { setError(s('email.error.empty')); input.focus(); return; }
        if (!EMAIL_RE.test(v)) { setError(s('email.error.invalid')); input.focus(); return; }
        setError('');
        if (form.querySelector('.tn-hp input').value) { block.classList.add('is-done'); return; }
        var label = btn.textContent; btn.textContent = s('email.sending'); btn.setAttribute('aria-disabled', 'true');
        function done() { block.classList.add('is-done'); block.querySelector('.tn-email__thanks').focus(); }
        function fail() { btn.textContent = label; btn.removeAttribute('aria-disabled'); setError(s('email.failed')); }
        var endpoint = (T.data && T.data.formEndpoint) || '';
        if (!endpoint) { setTimeout(done, 500); return; }   /* design preview: no endpoint chosen yet */
        fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ form: 'news', email: v, book: bookInput ? bookInput.value : '', lang: document.documentElement.lang || 'en' }) })
          .then(function (r) { r.ok ? done() : fail(); }, fail);
      });
    });
    each(root, '[data-tn-notify]', function (a) {
      a.addEventListener('click', function (e) {
        var block = document.getElementById((a.getAttribute('href') || '#news').slice(1)); if (!block) return;
        e.preventDefault();
        var key = a.getAttribute('data-tn-notify'), book = (T.data.books || []).concat((T.data.series || []).map(function (x) { return { key: x.key, title: { en: x.name } }; })).filter(function (b) { return b.key === key; })[0];
        var chip = block.querySelector('.tn-email__chip');
        if (book && chip) { block.querySelector('input[name="book"]').value = key; chip.querySelector('.tn-email__chip-text').textContent = book.title.en; chip.classList.add('is-on'); }
        block.classList.remove('is-done'); block.scrollIntoView({ block: 'center' });
        var input = block.querySelector('input[type="email"]'); if (input) input.focus({ preventScroll: true });
      });
    });
  };

  T.init = function (root) {
    document.documentElement.classList.add('tn-js');
    T.initReveal(root); T.initDepth(root); T.initTilt(root); T.initMenu(root); T.initEmail(root);
  };
})();
