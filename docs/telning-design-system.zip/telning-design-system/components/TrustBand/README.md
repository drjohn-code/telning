# TrustBand

"Made by scientists, made for play.": the trust block for parents. A lifted cream card: on one side a science desk on graph paper (an owl in glasses and a cap reading a book on a stack of books, a bubbling flask, a magnifier, a clipboard with ticks, a hanging bulb) and the Telning science seal, a red rosette whose ring of words turns slowly; on the other the heading, the team line ("Every Telning book is created by our team of cognitive and behavioural scientists.") and three proof points with small paper icons: Decision intelligence first, Four skills in every book, Made for reading together. One link: "Meet the team".

- Markup: `section.tn-trust` → `.tn-trust__art.tn-scene` (`.tn-trust__desk`, `.tn-layer`s, the `.tn-seal`) and `.tn-trust__body` (H2, lead, `ul.tn-trust__pts > li.tn-trust__pt` with `.tn-trust__ic` (`--c`) and `strong` + `span`, link).
- Desktop: art and words side by side. Phones: art on top (4:3), words under it.
- Only true, approved facts. Never "proven", "science-backed", "clinically tested" or a number from a study. Shown when `teamCreditOn` is true.
