# EmailBlock

"Letters from Pim": the news sign-up on a lifted cream card, with Pim's round portrait (art slot), heading, one line, field, button, consent line with the privacy link. A paper plane floats at its corner. "Tell me when it's out" links open it with that book chosen. Posts JSON to `formEndpoint`; a honeypot field stops spam bots; no cookies.
