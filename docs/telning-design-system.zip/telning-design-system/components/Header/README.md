# Header

Sticky, on blurred paper: the lockup (home link), the links Ages · Series · Skills · For grown-ups · About, and the language switch (only languages marked `ready`). Under 1024 px the links open from an `ink` "Menu" button.
