# BookCover

A book cover built from the cover system until the real cover exists. Until the first titles are set, the home page shows one cover per series (Home & Hearts, Star Hoppers, On the Move…; series name as the title): a `cream` cover with a band in the book's colour, the colophon, the series name in small capitals, the two-line title in Fraunces, and the art frame the illustrator fills.

- Markup: `.tn-cover` with `style="--book: var(--red)"` → `.tn-cover__band`, `.tn-colophon.tn-cover__colophon`, `.tn-cover__k`, `.tn-cover__t` (`.tn-cover__l1`, `.tn-cover__l2`), `.tn-cover__art`. Sizes follow the cover width.
- If the book has a `coverImage`, the cover is just that image with alt text.
- Wrap it in `.tn-tilt` to turn it toward the pointer in 3D.
