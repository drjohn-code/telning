# FormField

Label above; a white pill field 56 px tall with a 1 px ink line. Error: a 2 px `red-deep` line, an icon and words, never colour alone. Real labels only.
