# SeriesWorlds

The star of the home page: the twelve series as little paper worlds. Each card is a scene in its own colour (objects and cute animals standing on a cream paper hill), then the series name in Fraunces and the plain theme word parents search for. On hover the card tilts, the animals hop and wiggle their ears.

- Markup: `ul.tn-worlds > li > a.tn-world.tn-tilt` → `.tn-world__scene` (`--c`; `.tn-world__far`, `.tn-world__o` objects placed by left / bottom / width in %, `.tn-world__ground`) and `.tn-world__body` (`.tn-world__name`, `.tn-world__theme`).
- Four per row on desktop, three on tablets, two on phones.
- Scenes, names and themes come from the site data (`SERIES_SCENES`): Home & Hearts, Paws & Claws, Star Hoppers, Little Gardeners, Big Days, The Toy Box, Little Kitchen, Funny Pages, Round the Year, Game On, Everyday Heroes, On the Move.
- The animals here are decoration. Each series' real main character comes from the illustrator and replaces the scene when ready.
