# Objects

The paper object library: flat paper shapes in a lit, mid and shaded tone, so each one reads with volume. A soft drop shadow lifts it off the page. They are the playful layer of the site: they float, drift, drive and fly.

- Markup: inline SVG with class `tn-obj` and `--w` for its width; built from the colour tokens, so they recolour with the system. Files with fixed colours are in the asset group **Objects**.
- Motion classes: `tn-float` (bob), `tn-sway` (swing from the top), `tn-drift` (cross the stage), `tn-spin` (sun rays), `tn-flicker` (rocket flame), `tn-wheels` (car), `tn-glow` (bulb). All stop under `prefers-reduced-motion`.
- Series emblems: Home & Hearts `house`, Paws & Claws `paw`, Star Hoppers `rocket`, Little Gardeners `tulip`, Big Days `gift`, The Toy Box `blocks`, Little Kitchen `cupcake`, Funny Pages `bubble`, Round the Year `calendar`, Game On `ball`, Everyday Heroes `shield`, On the Move `car`. Skills: Decision intelligence `signpost` (the heart), Emotional intelligence `heart`, Social skills `seesaw`, Behavioural skills `steps`.
- Science desk (the trust block): `owl-prof` (owl in glasses and a cap, reading), `bookstack`, `flask` (bubbles rise: `tn-bubble`), `magnifier`, `clipboard`.
- Animals: fox, bear, bunny, cat, owl, duck, frog, elephant (in a hero cape), penguin, whale, hedgehog, snail, bee. Cute and a little funny: round shapes, dot eyes that blink (`.o-eyes`), ears that wiggle on hover (`.o-ears`), hops (`tn-hop`, `tn-hop-idle`), a peek (`tn-peek`).
- Decoration only: never Pim, a series main character or a book page. Those come from the illustrator, who may also redraw any object or animal in the same size and place.
