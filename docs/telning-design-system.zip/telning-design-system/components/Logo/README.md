# Logo

The Telning logo: the colophon (an open book that forms a "T" and a young tree, in a rounded red badge) beside "Telning" in Fraunces 600 and "PUBLISHING HOUSE" in Instrument Sans 600 under it. The second line is letter-spaced so it runs exactly from the left edge of "Telning" to its right edge: both lines share the same borders.

- Files: asset group **Logo** (`lockup.svg`, `lockup-stacked.svg`, `lockup-mono.svg`, `colophon.svg`, `colophon-mono.svg`, `favicon.svg`, `favicon-32.png`, `apple-touch-icon.png`, `profile.svg`, `og-image.png`). The words are paths, so no font is needed.
- Colourways: `red` badge + `ink` words on `paper` or `cream` (main); `cream` badge with `forest` book + `cream` words on `forest`; `red` + `cream` on `ink`; one-colour `ink` on `white`. The mono files use `currentColor` with the book cut out.
- The colophon alone works from 16 px. It sits on every book spine and in the corner of every cover.
- Never: recolour the book inside the badge, stretch, add effects, set the name in another font.
