# ArtSlot

Where the illustrator's art goes: white, 1 px ink line, `radius-m`, a fixed shape (1:1, 2:1, 4:5, 4:3). In development it shows the file name it waits for. Nobody draws into it. The site does not go live with an empty slot.
