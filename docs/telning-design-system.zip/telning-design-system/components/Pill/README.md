# Pill

Small labels. `tn-pill`: cream with a 1 px ink line (the age of a book, read from its `age`); `tn-pill--dark`: ink with cream text (status: "Coming soon", "Out now"). Use pills only on book cards and book pages; no rows of small facts elsewhere.
