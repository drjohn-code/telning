# PimNote

Pim is the Telning character: the brand's voice. Pim greets visitors, explains, signs the letters and the story cards. Pim is not part of any series.

- Markup: `figure.tn-pim` → `.tn-pim__art` (a round art slot until the illustrator's Pim exists; then an `<img>` with alt "Pim, the Telning character") and `figcaption.tn-pim__bubble` (a hidden "Pim:" for screen readers, then the line). No visible signature: the portrait shows who speaks. Sizes: default, `tn-pim--sm`.
- Pim's voice: first person, warm, short (one sentence, at most 14 words), a little playful, always about choosing. Never a claim, never advice about a child's health.
- Where: the hero greeting, beside the skills, the "send your ending" card, the email block ("Letters from Pim") and every story card.
- Code never draws Pim. Only the illustrator does.
