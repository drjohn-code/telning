# LandingPage

The home page in the paper-theatre style. Order: header → hero (H1, lead, "Find a book by age", link; the stage with Pim's greeting) → the quiet age strip → Our series (twelve series worlds, the star) → Decision intelligence at the heart (the skill heart) → the TADA band → Send Pim your ending → Made by scientists (the trust block) → Letters from Pim (email) → footer. No kickers, section numbers or rows of small facts.

- Depth: the stage and the story card follow the pointer; cards tilt; spines slide out; objects float, drift, drive and fly; sections rise in as you scroll. Under reduced motion all of it stands still.
- Phones: one column; series in two columns; smaller type (H1 40, H2 28, body 16 px), compact TADA rows, fewer objects.
- Copy marked as draft in the site data needs a person's edit. Art slots wait for the illustrator.
