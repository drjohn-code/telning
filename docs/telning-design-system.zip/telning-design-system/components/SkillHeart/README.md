# SkillHeart

Telning's difference in one block. Every book brings in all four skills; decision intelligence leads. The big `forest` card holds Decision intelligence with its signpost object (two ways to go); beside it, three cream rows hold the skills woven into every story: Emotional intelligence (heart), Social skills (seesaw), Behavioural skills (steps), and a Pim note.

- Markup: `.tn-skillmap` → `.tn-skillmain.tn-tilt` (`.tn-skillmain__obj`, kicker, `.tn-skillmain__h`, lead) and `.tn-skillside` (kicker, `ul.tn-skillrows > li.tn-skillrow`, PimNote).
- Decision intelligence always comes first and biggest. Describe what the child does; never promise a result ("smarter", "proven", "builds").
