# Button

The one main action on a screen: an `ink` pill with `cream` text, Instrument Sans 600 18 px, 56 px tall, `shadow-2`. On hover it lifts 2 px, turns `forest` and takes `shadow-3`.

- Markup: `<a class="tn-btn">` or `<button class="tn-btn">`. Links: `<a class="tn-link">`: `ink` text with a `red` underline that thickens on hover; `tn-link--solo` gives a 48 px target.
- One button per screen; every other action is a link.
- Focus: a 3 px `sea-deep` ring with a 3 px gap, on everything.
