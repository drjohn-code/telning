# Stage

The hero scene: a paper theatre. Layers of paper hills, clouds, the sun, a tree, a signpost (the choice), three series covers and a driving car sit inside a rounded sky box, with a hopping bunny and a bee; a balloon and blocks float in front of its edges, a fox peeks in from the corner, and Pim greets the visitor from the left. Every layer has a depth (`--d`); `Telning.initDepth()` moves each one by its depth when the pointer moves and when the page scrolls, so the scene feels 3D.

- Markup: `.tn-stage.tn-scene` → `.tn-stage__box` (clipped) with `.tn-layer` children, then unclipped `.tn-layer`s for the objects in front. Put `data-depth-area` on the section that should track the pointer.
- Phones: a shorter stage, fewer objects (`tn-hide-sm`), no pointer depth; gentle motion stays.
- Reduced motion: everything stands still.
