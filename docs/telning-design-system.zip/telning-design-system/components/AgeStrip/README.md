# AgeStrip

The quick way in by age, kept quiet so the series lead: one heading and three light cards (0–3 Baby and toddler, 3–5 Preschool, 5–7 Early school). Each card has a small coloured disc with the age, the name, and a little animal that hops on hover.

- Markup: `.tn-ages` → `h2.tn-ages__h`, `ul.tn-agestrip > li > a.tn-agechip` with `--c` (disc colour) → `.tn-agechip__n`, `.tn-agechip__l`, `.tn-agechip__obj`.
- Desktop: heading and the three cards in one row. Phones: heading, then the cards stacked.
