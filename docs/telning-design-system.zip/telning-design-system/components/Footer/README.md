# Footer

A `forest` footer that rises in a soft paper hill, with a hedgehog and a snail walking on top: the cream lockup and twelve links; then a bottom bar with "© 2026 WelloWork AB, Telning Publishing House" (year from `legal.copyrightYear`) and two outlined pill links, Instagram and TikTok (icon + name; screen readers hear "Telning on Instagram").

- The icons are simple generic glyphs (a camera, a music note). Swap in each platform's official icon from its brand resources if wanted; keep the name beside it.
- A link shows only when its URL is set in `social.instagram` / `social.tiktok`.
