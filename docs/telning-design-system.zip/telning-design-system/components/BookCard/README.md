# BookCard

One book in a list: the cover (with tilt), the title, the age pill, the status pill and one link ("Tell me when it's out", or "See it on Amazon" once out). No price, no stars.
