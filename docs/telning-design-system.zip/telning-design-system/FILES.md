# Telning design system: what is in this folder

Version 12 (7 October 2026). Telning Publishing House, "The Publisher" paper-theatre look.

- `preview/index.html`: open this first. Every component and the landing page, working offline in any browser.
- `README.md`: the brand book (rules, voice and words, colour, type, logo, series, ages, skills).
- `tokens.json`: every colour, type style, space, radius, shadow and motion value. `tokens.css`: the same as CSS variables.
- `components/`: `bundle.css` (all `tn-` classes), `bundle.js` (`window.Telning`: depth, tilt, reveal, menu, email form, site data, strings) and one folder per component with its `preview.html` and `README.md`.
- `fonts/`: Fraunces and Instrument Sans (woff2) with their SIL Open Font License files.
- `assets/Logo/`: lockups, colophon, favicons, profile picture, social sharing image.
- `assets/Animals/`, `assets/Objects/`, `assets/Science desk/`: every paper object and animal as an SVG file.
- `assets/Site data/`: `site-data.json` (series, ages, skills, links, switches) and `strings.en.json` (all English text; `de` and `sv` files share the keys).
- `source/`: the Python scripts and source CSS/JS that generated everything (they use the paths of the machine they were built on; for reference and rebuilding).
