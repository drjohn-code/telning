# Animals

Cute paper animals for the website: fox, bear, bunny, cat, owl, duck, frog, elephant (in a hero cape), penguin, whale, hedgehog, snail, bee. Files with fixed colours; the pages inline them with colour tokens so eyes can blink and ears wiggle. Decoration only: not Pim and not a series main character. The illustrator may redraw any of them.
