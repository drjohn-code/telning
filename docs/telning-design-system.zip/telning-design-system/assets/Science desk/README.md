# Science desk

The paper objects of the "Made by scientists" trust block (TrustBand): an owl in glasses and a cap reading a book (`owl-prof`), a stack of books, a flask with rising bubbles, a magnifier and a clipboard with ticks. Fixed-colour files; the page inlines them with colour tokens. Decoration only; the illustrator may redraw them in the same size and place.
