# Logo

The colophon and lockups. Colour files: `red` badge, `cream` book, `ink` words. `-mono` files: one ink, `currentColor` (black in an `<img>`; inline them and set `color`). The words are paths; no font needed.

- `lockup.svg`, `lockup-stacked.svg`, `lockup-mono.svg`
- `colophon.svg`, `colophon-mono.svg`
- `favicon.svg`, `favicon-32.png`, `apple-touch-icon.png` (180 px)
- `profile.svg` (1080 px, colophon in the middle 70% of the circle)
- `og-image.png` (1200 × 630, lockup and "Little stories, growing minds.")
