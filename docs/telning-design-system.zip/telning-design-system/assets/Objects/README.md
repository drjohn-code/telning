# Objects

The paper object library as files with fixed colours (the pages inline them with colour tokens instead). Objects only: no characters, no faces. The illustrator may redraw any of them in the same size and place.
