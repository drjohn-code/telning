# Site data

The facts and text the pages read. Empty values mean "not known yet": hide that part, never show a made-up value.

- `site-data.json`: publisher, taglines, social, switches, languages, ages, formats, skills, the twelve series (name, emblem, colour, status) and the books (empty until the first real titles are set).
- `strings.en.json`: all English text. `strings.de.json`, `strings.sv.json`: the same keys, empty until a person writes them.
